from .models import Purchase

def active_background(request):
    if request.user.is_authenticated:
        #fetch the user's active background purchas
        active_purchase = Purchase.objects.filter(user=request.user, is_active_background=True).first()
        return {'active_purchase': active_purchase}
    return {'active_purchase': None}
