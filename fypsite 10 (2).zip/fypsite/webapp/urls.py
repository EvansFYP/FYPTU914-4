from django.urls import path

from . import views

app_name = "webapp"
urlpatterns = [
path("signup/", views.signup, name ="signup"),
path("signin/", views.signin, name = "signin"),
path("home/", views.homeview, name="home"),
path("additem/", views.additem, name ="additem"),
path("viewitem/", views.viewitem, name ="viewitem"),
path('itemdetail/<int:item_id>/', views.itemdetail, name='itemdetail'),
path('goals', views.goals, name='goals'),
path('item/delete/<int:item_id>/', views.deleteitem, name='deleteitem'),
path('item/edit/<int:item_id>/', views.edititem, name='edititem'),
path('outfit/<str:outfit_date>/', views.outfit_detail, name='outfit_detail'),
path('calculate_sustainability_metrics/', views.calculate_sustainability_metrics, name='calculate_sustainability_metrics'),
path('create_goal/', views.create_goal, name='create_goal'),
path('goals_list/', views.goals_list, name='goals_list'),
path('goal/cancel/<int:goal_id>/', views.cancel_goal, name='cancel_goal'),
path("settings/work-schedule/", views.work_schedule, name="work_schedule"),
path('swap_outfit/<str:outfit_date>/<int:item_id>/', views.swap_outfit, name='swap_outfit'),
path('confirm_swap/<str:outfit_date>/<int:item_id>/<int:replacement_id>/', views.confirm_swap, name='confirm_swap'),
path('wear_outfit/<str:outfit_date>/', views.wear_outfit, name='wear_outfit'),
path('leaderboard/', views.leaderboard, name='leaderboard'),
path('shop/', views.shop, name='shop'),
path('set-active-background/<int:product_id>/', views.set_active_background, name='set_active_background'),
path('set-active-background/default/', views.set_active_background, name='set_default_background'), 
path('purchase_product/<int:product_id>/', views.purchase_product, name='purchase_product'), 
path("extract/", views.extract_product_view, name="extract_product_view"),
path('wishlist/', views.view_wishlist, name='view_wishlist'),
path('wishlist/add/<int:item_id>/', views.add_to_wishlist, name='add_to_wishlist'),
path('wardobe/add/<int:item_id>/', views.add_to_wardrobe, name='add_to_wardrobe'),
path('wishlist/remove/<int:item_id>/', views.remove_from_wishlist, name='remove_from_wishlist'),
path('goals/<int:goal_id>/verify/', views.verify_goal_listing, name='verify_goal_listing'),
path('map', views.map_view, name='map_view'),
path('item/<int:item_id>/favourite/', views.toggle_favourite, name='toggle_favourite'),

 

 
 
] 