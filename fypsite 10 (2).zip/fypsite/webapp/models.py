from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin




SIZE_CHOICES = [
    ("XS", "Extra Small"),
    ("S", "Small"),
    ("M", "Medium"),
    ("L", "Large"),
    ("XL", "Extra Large"),
   
] 

SHOE_SIZE_SYSTEM_CHOICES = [
    ("EU", "EU Size"),
    ("US", "US Size"),
    ("UK", "UK Size"),
]

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    preferred_size = models.CharField(max_length=25, choices=SIZE_CHOICES, blank=True, null=True)
    preferred_footwear_size = models.CharField(max_length=4, blank=True, null=True)
    footwear_size_system = models.CharField(max_length=2, choices=SHOE_SIZE_SYSTEM_CHOICES, blank=True, null=True)

    def __str__(self):
        return f"{self.user.username}'s profile"

    

class ClothingItem(models.Model):
    CATEGORY_CHOICES = [
        ('TOP', 'Top'),
        ('BOTTOM', 'Bottom'),
        ('FOOTWEAR', 'Footwear'),
        ('OUTERWEAR', 'Outerwear'),
        ('ACCESSORY', 'Accessory'),
    ]



    SUBCATEGORY_CHOICES = {
        'TOP': [
            ('SHIRT', 'Shirt'),
            ('T-SHIRT', 'T-Shirt'),
            ('BLOUSE', 'Blouse'),
            ('POLO', 'Polo Shirt'),
            ('TURTLE', 'Turtle Neck'),
            ('TANK_TOP', 'Tank Top'),
            ('CROP_TOP', 'Crop Top'),
            ('DRESS', 'Dress'),
            ('LONG_SLEEVE', 'Long Sleeved'),
            ('TUBE_TOP', 'Tube Top'),
           ],

        'BOTTOM': [
            ('JEANS', 'Jeans'),
            ('SHORTS', 'Shorts'),
            ('DRESS_PANTS', 'Dress Pants'),
            ('SKIRT', 'Skirt'),
            ('LEGGINGS', 'Leggings'),
            ('JOGGERS', 'Joggers'),
            ('PENCIL_SKIRT', 'Pencil Skirt'),  
            ('CHINOS', 'Chinos'),
        ],

        'FOOTWEAR': [
            ('SNEAKERS', 'Sneakers'),
            ('BOOTS', 'Boots'),
            ('SANDALS', 'Sandals'),
            ('LOAFERS', 'Loafers'),
            ('HEELS', 'Heels'),
            ('DRESS_SHOES', 'Dress Shoes'),

        ],
        'OUTERWEAR': [
            ('JACKET', 'Jacket'),
            ('COAT', 'Coat'),
            ('WINDBREAKER', 'Windbreaker'),
            ('LIGHT_JACKET', 'Light Jacket'),
            ('FLANNEL', 'Flannel Shirt'),
            ('SWEATER', 'Sweater'),
            ('HOODIE', 'Hoodie'),
            ('CARDIGAN', 'Cardigan'),
            ('WAIST_COAT', 'Waist Coat'),
            ('BLAZER', 'Blazer'),
        ],
        'ACCESSORY': [
            ('HAT', 'Hat'),
            ('SCARF', 'Scarf'),
            ('BELT', 'Belt'),
            ('GLOVES', 'Gloves'),
            ('WATCH', 'Watch'),
            ('SUNGLASSES', 'Sunglasses'),
            ('TIE', 'Tie'),
        ],
    }







    MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('R-WOOL', 'Recycled Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),
        ('OTHER', 'Other'),


    ]




    

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='clothing_items')
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='clothing_items/', blank=True, null=True)
    second_hand = models.BooleanField(default=False)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    subcategory = models.CharField(max_length=50, blank=True, null=True)
    material = models.CharField(max_length=150, blank=True, null=True)
    colour = models.CharField(max_length=30, blank=True, null=True)
    size = models.CharField(max_length=20, blank=True, null=True)
    purchase_date = models.DateField(blank = True, null = True)
    date_added = models.DateField(default=timezone.now)
    last_worn_date = models.DateField(blank=True, null=True)
    worn_count = models.PositiveIntegerField(default=0)
    brand = models.CharField(max_length=100, blank=True, null=True)
    sustainable_material = models.BooleanField(default=False, blank =True, null = True)
    wash_count = models.PositiveIntegerField(default = 0)
    material_sustainability_score = models.PositiveIntegerField(default=0)
    carbon_savings = models.PositiveIntegerField(default=0)
    carbon_used= models.PositiveIntegerField(default=0)
    last_worn_update = models.DateField(null=True, blank=True)
    is_favorite = models.BooleanField(default=False)
    skip_count = models.PositiveIntegerField(default=0)
    last_suggested = models.DateTimeField(null=True, blank=True)
    
    
    
    #percentage going from 0-100 
    MATERIAL_SUSTAINABILITY_SCORE = {
    # Best (Higg MSI 0-20)
    'LYOCELL': 10,       # Higg: 10 (TENCEL™ closed-loop)
    'HEMP': 15,          # Higg : ~15 (low water, no pesticides)
    'R-WOOL': 20,        # Higg : ~20 (recycled reduces impact)
    'BAMBOO': 25,        # Higg : ~25 (sustainably processed)
    
    # Excellent (Higg MSI 20-40)
    'LINEN': 30,  
    'R-COTTON' : 30,     # Higg: ~30 (low water, biodegradable)
    'R-POLYESTER': 35,   # Higg: ~35 (recycled but microplastics)
    'MODAL': 40,         # Higg: ~40 (better than viscose)
    
    # Moderate (Higg MSI 40-60)
    'ORGANIC_COTTON': 45, # Higg: ~45 (better than conventional)
    'WOOL': 50,          # Higg: ~50 (methane emissions)
    'DENIM': 55,         # Higg: ~55 (water-intensive)
    'COTTON': 60,        # Higg: 60 (conventional)
    
    # Poor (Higg MSI 60-100)
           # Higg: ~70 (varies by tanning process)
    'NYLON': 75,         # Higg: 75 (energy-intensive)
    'POLYESTER': 80,     # Higg: 80 (virgin polyester)
    'RAYON': 85,         # Higg: ~85 (chemical-heavy)
    'VISCOSE': 85,       # Higg: ~85 (similar to rayon)
    'ACRYLIC': 90,       # Higg: ~90 (high pollution)
    
    # Worst (Higg MSI 100+)
    'LEATHER': 100,
    'SYNTHETIC': 100,    # Generic worst-case
    'SPANDEX': 100,      # Higg: ~100 (non-recyclable)
    'ELASTANE': 100,     # Same as spandex
    'OTHER': 70,         # Default assumption (moderate-high impact)
}



    def wear(self): 
        self.worn_count += 1
        self.last_worn_date = timezone.now()
        self.save()
    
    def wash(self):
        self.wash_count += 1
        self.save()

    def get_subcategories(category):
     subcategories = ClothingItem.SUBCATEGORY_CHOICES.get(category, [])
     return subcategories


class Outfit(models.Model):
    name = models.CharField(max_length=100)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='outfit')
    clothing_items = models.ManyToManyField(ClothingItem, related_name="outfits")
    created_date = models.DateTimeField(auto_now_add=True)

    

    def __str__(self):
        return self.name
    

class Outfit_Schedule(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='outfit_schedule')
    outfit = models.ForeignKey(Outfit, on_delete=models.CASCADE, related_name='outfit_schedule')
    weather_condition = models.CharField(max_length=100)
    outfit_date = models.DateField(blank=True, null=True)

    OCCASION_CHOICES = [
        ('WORK_CASUAL', 'Work Casual'),
        ('WORK_FORMAL', 'Work Formal'),

        
    ]
    
    occasion = models.CharField(max_length=20, choices=OCCASION_CHOICES, blank=True, null=True)

class Sustainability_Metrics(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sustainability_metrics')
    carbon_savings = models.PositiveIntegerField(default=0)
    item_usage_percentage = models.PositiveIntegerField(default=0)
    second_hand_percentage = models.PositiveIntegerField(default=0)
    sustainable_score = models.PositiveIntegerField(default=0)
    reportDate = models.DateField(default=timezone.now)
    carbon_used = models.PositiveIntegerField(default=0)

class Goal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='goal')
    description = models.CharField(max_length=200)
    start_date = models.DateField(default=timezone.now)  
    end_date = models.DateField()  
    
    GOAL_CHOICES = [
        ('carbon_savings', 'Improve Carbon Savings'),
        ('second_hand', 'Buy Second-Hand Items'),
        ('clothing_recycling', 'Recycle or Donate Clothing'),
        ('sustainable_choices', 'Acquire Sustainable Items'),
    ]
    
    goal_type = models.CharField(max_length=50, choices=GOAL_CHOICES, default='sustainable_score')
    
    STATUS_CHOICES = [
        ('ONGOING', 'Ongoing'),
        ('COMPLETE', 'Complete'),
        ('FAILED', 'Failed'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ONGOING')
    improvement_target = models.PositiveIntegerField(null=True, blank=True)
    progress = models.PositiveIntegerField(default=0) 
    initial_score = models.PositiveIntegerField(null=True, blank=True)
    verification_code = models.CharField(max_length=8, unique=True, blank=True)
    verification_urls = models.JSONField(default=list, blank=True)  # Stores verified listing URLs
    
    def save(self, *args, **kwargs):
        if not self.verification_code and self.goal_type in ['clothing_recycling']:
            self.verification_code = self.generate_verification_code()
        super().save(*args, **kwargs)
    
    def generate_verification_code(self):
        import random
        import string
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

    def __str__(self):
        return f"{self.user.username} - {self.get_goal_type_display()} - {self.status}"


class Point(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='points')
    points_total = models.PositiveIntegerField(default=0)
    points_earned = models.PositiveIntegerField(default=0)
    points_current = models.PositiveIntegerField(default=0)
    coins = models.PositiveIntegerField(default=0)  
    date_earned = models.DateField(auto_now_add=True)
    points_reason = models.CharField(max_length=255)

    def earn_points(self, amount, reason):
        previous_total = self.points_total
        self.points_earned += amount
        self.points_total += amount
        self.points_reason = reason
        self.save()

        
        new_total = self.points_total
        thresholds_crossed = (new_total // 100) - (previous_total // 100)
        if thresholds_crossed > 0:
            self.coins += 5 * thresholds_crossed
            self.save() 

class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlist')
    item_name = models.CharField(max_length=100) 
    source = models.URLField(blank=True, null=True)  
    material = models.CharField(max_length=50, blank=True, null=True)  
    sustainable_score = models.PositiveIntegerField(default=0)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='wishlist_items/', blank=True, null=True)
    second_hand = models.BooleanField(default=False)
    category = models.CharField(max_length=20, choices=ClothingItem.CATEGORY_CHOICES, blank=True, null=True)
    subcategory = models.CharField(max_length=50, blank=True, null=True)
    size = models.CharField(max_length=20, blank=True, null=True)
    brand = models.CharField(max_length=100, blank=True, null=True)
    colour = models.CharField(max_length=30, blank=True, null=True)
    carbon_savings = models.PositiveIntegerField(default=0)
    carbon_used= models.PositiveIntegerField(default=0)
    

 
class WorkSchedule(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='work_schedule')
 
    WORK_TYPE_CHOICES = [
        ('WORK_CASUAL', 'Work Casual'),
        ('WORK_FORMAL', 'Work Formal'),
    ]

    works = models.BooleanField(default=False)  
    work_type = models.CharField(max_length=20, choices=WORK_TYPE_CHOICES, blank=True, null=True)
    work_days = models.CharField(
        max_length=100, 
        blank=True,
        help_text="Comma-separated days, e.g., Monday,Tuesday,Friday"
    )

    def get_work_days_list(self):
        return self.work_days.split(",") if self.work_days else []

    def __str__(self):
        return f"{self.user.username}'s Work Schedule"



class Product(models.Model):
    CATEGORY_SHOP = [
        ('background', 'Background'),
        ('theme', 'Theme'),
        ('item', 'Item'),
    ]
    name = models.CharField(max_length=100)
    category = models.CharField(max_length=20, choices=CATEGORY_SHOP)
    image = models.ImageField(upload_to='products/')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    users = models.ManyToManyField(User, blank=True, related_name='products')

    def __str__(self):
        return self.name

class Purchase(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    purchased_at = models.DateTimeField(auto_now_add=True)
    is_active_background = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.user.username} purchased {self.product.name}"











    



 