from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.views import generic
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.utils.dateparse import parse_datetime
from django.contrib import admin
from colorthief import ColorThief
import requests
from django.http import JsonResponse
import requests
from datetime import date, timedelta, datetime 
from django.utils import timezone
import webcolors
import matplotlib
import numpy as np
from sklearn.neighbors import NearestNeighbors
from skimage.color import rgb2lab






from .models import User
from .models import ClothingItem
from .models import Outfit, Outfit_Schedule

CATEGORY_CHOICES = [
    ('TOP', 'Top'),
    ('BOTTOM', 'Bottom'),
    ('FOOTWEAR', 'Footwear'),
    ('OUTERWEAR', 'Outerwear'),
    ('ACCESSORY', 'Accessory'),
]

MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),


    ]


def signup(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signup.html", context)
    else:
        user = User.objects.create_user(
            username=request.POST["Username"],
            password=request.POST["Password"]
        )
        
        return HttpResponseRedirect(reverse("webapp:signin"))

def signin(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signin.html", context)
    else:
        user = authenticate(
            request,
            username=request.POST["Username"],
            password=request.POST["Password"]
        )

        if user is not None:
            login(request, user)
            print("logged in", user)
            return HttpResponseRedirect(reverse("webapp:home"))

def get_lat_lon(ip_address=""):
    #token
    token = "109bd2515f0ad5"  
    #API URL
    url = f"https://ipinfo.io/{ip_address}?token={token}" if ip_address else f"https://ipinfo.io/?token={token}"

    try:
        #send request to IPinfo
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()

      
        location = data.get("loc")
        if location:
            latitude, longitude = map(float, location.split(","))
            return latitude, longitude
        else:
            print("Location not found in the response.")
            return None, None
    except requests.RequestException as e:
        print(f"Error while retrieving geolocation data: {e}")
        return None, None


latitude, longitude = get_lat_lon()
print(f"Your Latitude: {latitude}, Your Longitude: {longitude}")

def fetch_weather_forecast(latitude, longitude):
  
    api_key = "GBWM6TUL5HEYSSSTUSAEFPVH6"
    weather_url = (
        f"https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast"
        f"?key={api_key}&unitGroup=metric&contentType=json&aggregateHours=24&locations={latitude},{longitude}"
    )
    weather_response = requests.get(weather_url)
    weather_data = weather_response.json()

    # Extract the forecast for the next 7 days
    location_key = f"{latitude},{longitude}"
    forecast_data = weather_data['locations'][location_key]['values'][:7]

    # Convert timestamps to datetime objects
    for day in forecast_data:
        timestamp = day['datetime']
        day['datetime'] = datetime.utcfromtimestamp(timestamp / 1000)  

    return forecast_data



def homeview(request):
    if request.method == "GET":
        latitude, longitude = get_lat_lon()

        
        forecast_data = fetch_weather_forecast(latitude, longitude)

        user = request.user 

       
        scheduled_outfits = schedule_outfits_for_forecast(user, forecast_data)

        # Check for errors (e.g., no clothing items)
        if 'error' in scheduled_outfits:
            context = {
                'error': scheduled_outfits['error'],
                'forecast': forecast_data,
            }
            return render(request, 'webapp/home.html', context)

        
        context = {
            'outfits_for_week': scheduled_outfits,
            'forecast': forecast_data,
        }
        return render(request, 'webapp/home.html', context)

    return render(request, 'webapp/home.html', {'error': 'Invalid request method.'})

    


color_names = ["white", "black", "red", "green", "blue", "yellow", "gray", "brown", "pink", "orange", "purple"]
rgb_values = [
    (255, 255, 255),  # white
    (0, 0, 0),        # black
    (255, 0, 0),      # red
    (0, 255, 0),      # green
    (0, 0, 255),      # blue
    (255, 255, 0),    # yellow
    (128, 128, 128),  # gray
    (139, 69, 19),    # brown
    (255, 192, 203),  # pink
    (255, 165, 0),    # orange
    (128, 0, 128),    # purple
]

# Convert RGB values to LAB
rgb_values_lab = rgb2lab(np.array(rgb_values).reshape(-1, 1, 3) / 255).reshape(-1, 3)

def rgb_to_color_name(rgb):
    # Convert input RGB to LAB
    rgb_lab = rgb2lab(np.array(rgb).reshape(1, 1, 3) / 255).reshape(1, -1)
    
    # Fit Nearest Neighbors in LAB color space
    nbrs = NearestNeighbors(n_neighbors=1).fit(rgb_values_lab)
    distances, indices = nbrs.kneighbors(rgb_lab)
    
    # Return the closest color name
    closest_name = color_names[indices[0][0]]
    print(f"RGB: {rgb}, Closest Color: {closest_name}, Distance: {distances[0][0]}")  # Debugging information
    return closest_name   
    
def additem(request):
    if request.method == "GET":
        context = {'categories': CATEGORY_CHOICES, 'material' : MATERIAL_CHOICES }
        return render(request, "webapp/additem.html", context)
    else:
        
        item_name = request.POST["name"]
        second_hand = request.POST["second_hand"]
        if second_hand == "true":
            is_second_hand = True
        else:
            is_second_hand = False
        category = request.POST["category"] 
        material = request.POST["material"]
        size = request.POST["size"]
        purchase_date = request.POST["purchase_date"]
        if purchase_date == "":
            purchase_date = None 
        price = request.POST["price"]
        brand = request.POST["brand"]
        description = request.POST["description"]
        image = request.FILES.get("image", None)

        sustainable_material = False
        if material in ['COTTON', 'LINEN', 'BAMBOO', 'R-POLYESTER', 'LYOCELL', 'MODAL']:
            sustainable_material = True


        colour = None
        if image:
            color_thief = ColorThief(image)
            dominant_rgb = color_thief.get_color(quality=10)
            colour = rgb_to_color_name(dominant_rgb)
            
            

        
          

        
        
        clothing_item = ClothingItem.objects.create(
            name=item_name,
            second_hand=is_second_hand,
            category =category,
            material = material,
            colour = colour,
            size = size,
            purchase_date = purchase_date,
            price = price,
            brand = brand,
            sustainable_material=sustainable_material,
            description = description,
            image=image,
            user=request.user

        )

        
        return HttpResponseRedirect(reverse("webapp:home"))
    


def viewitem(request):
    items = ClothingItem.objects.filter(user=request.user)  
    context ={'items': items }
    return render(request, 'webapp/viewitem.html',context)


def itemdetail(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    context = {
        'item': item,
    }
    
    
    return render(request, 'webapp/itemdetail.html', context)

def goals(request):
     if request.method == "GET":
        context = {}
        return render(request, "webapp/goals.html", context)


def deleteitem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    if request.method == 'GET':
        item.delete()
        return redirect('webapp:viewitem')
    

def edititem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    categories = ClothingItem.CATEGORY_CHOICES  
    materials = ClothingItem.MATERIAL_CHOICES  

    if request.method == "POST":
       
        item.name = request.POST["name"]
        item.second_hand = request.POST["second_hand"] == "true"
        item.category = request.POST["category"]
        item.material = request.POST["material"]
        item.colour = request.POST["colour"]
        item.size = request.POST["size"]
        item.purchase_date = request.POST["purchase_date"] if request.POST["purchase_date"] else None
        item.price = request.POST["price"]
        item.brand = request.POST["brand"]
        item.description = request.POST["description"]
        item.image = request.FILES.get("image", item.image)  

       
        sustainable_material = item.material in ['COTTON', 'LINEN', 'BAMBOO', 'R-POLYESTER', 'LYOCELL', 'MODAL']
        item.sustainable_material = sustainable_material
        
        
        item.save()

      
        return redirect('webapp:viewitem')

    context = {
        'item': item,
        'categories': categories,
        'materials': materials
    }
    return render(request, "webapp/edititem.html", context)

def select_outfit_based_on_weather(temp, conditions, user, occasion=None):
    
    if temp > 20:
        outfit_categories = ['TOP', 'BOTTOM', 'FOOTWEAR']
    elif 10 < temp <= 20:
        outfit_categories = ['TOP', 'BOTTOM', 'FOOTWEAR', 'OUTERWEAR']
    else:
        outfit_categories = ['TOP', 'BOTTOM', 'FOOTWEAR', 'OUTERWEAR', 'ACCESSORY']

    
    if 'Rain' in conditions:
        outfit_categories.append('OUTERWEAR')

    outfit_items = []  # List to store selected clothing items

   #loops through finds an item by order of worn count and adds it to the list and applies the wear method to add an extra wear to the item
    for category in outfit_categories:
       
        items = ClothingItem.objects.filter(category=category).order_by('worn_count', 'last_worn_date')

       
        if items.exists():
            selected_item = items.first()  
            outfit_items.append(selected_item)  
            selected_item.wear()  

    
    if outfit_items:
      #creates new outfit for the user from the list of clothing items added
        outfit = Outfit.objects.create(name=f"Outfit for {user.username}", user=user)
        outfit.clothing_items.set(outfit_items) 
        outfit.save()  

       #then creates the corresponding schedule object
        if occasion:
            Outfit_Schedule.objects.create(
                user=user,
                outfit=outfit,
                weather_condition=f"{temp}°C, {conditions}",
                occasion=occasion
            )

        return outfit
    else:
    
        return None


def schedule_outfits_for_forecast(user, forecast_data):

    outfits_for_week = [] 

    #Check if the user has clothing items
    if not user.ClothingItems.exists():
        return {'error': 'No clothing items available for this user.'}

 #loops through forecast
    for i, day_forecast in enumerate(forecast_data):
        temp = day_forecast['temp']
        conditions = day_forecast['conditions']
        outfit_date = date.today() + timedelta(days=i)

        # Check if an outfit is already scheduled for this date
        outfit_schedule = Outfit_Schedule.objects.filter(user=user, outfit_date=outfit_date).first()

        if outfit_schedule:
            outfits_for_week.append(outfit_schedule.outfit) 
            # Generate a new outfit if none exists
            outfit = select_outfit_based_on_weather(temp, conditions, user)
            if outfit:
                Outfit_Schedule.objects.create(
                    user=user,
                    outfit=outfit,
                    weather_condition=f"{temp}°C, {conditions}",
                    outfit_date=outfit_date
                )
                outfits_for_week.append(outfit)

    return outfits_for_week
    



    