from django.contrib import admin

from .models import ClothingItem
from .models import Outfit
from .models import Outfit_Schedule

admin.site.register(ClothingItem)
admin.site.register(Outfit)
admin.site.register(Outfit_Schedule)