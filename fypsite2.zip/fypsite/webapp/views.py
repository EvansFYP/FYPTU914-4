from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.views import generic
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.utils.dateparse import parse_datetime
from django.contrib import admin
from colorthief import ColorThief

from .models import User
from .models import ClothingItem
CATEGORY_CHOICES = [
    ('TOP', 'Top'),
    ('BOTTOM', 'Bottom'),
    ('FOOTWEAR', 'Footwear'),
    ('OUTERWEAR', 'Outerwear'),
    ('ACCESSORY', 'Accessory'),
]

MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),


    ]


def signup(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signup.html", context)
    else:
        user = User.objects.create_user(
            username=request.POST["Username"],
            password=request.POST["Password"]
        )
        
        return HttpResponseRedirect(reverse("webapp:signin"))

def signin(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signin.html", context)
    else:
        user = authenticate(
            request,
            username=request.POST["Username"],
            password=request.POST["Password"]
        )

        if user is not None:
            login(request, user)
            print("logged in", user)
            return HttpResponseRedirect(reverse("webapp:home"))

def homeview(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/home.html", context) 
    
def additem(request):
    if request.method == "GET":
        context = {'categories': CATEGORY_CHOICES, 'material' : MATERIAL_CHOICES }
        return render(request, "webapp/additem.html", context)
    else:
        
        item_name = request.POST["name"]
        second_hand = request.POST["second_hand"]
        if second_hand == "true":
            is_second_hand = True
        else:
            is_second_hand = False
        category = request.POST["category"] 
        material = request.POST["material"]
        size = request.POST["size"]
        purchase_date = request.POST["purchase_date"]
        if purchase_date == "":
            purchase_date = None 
        price = request.POST["price"]
        brand = request.POST["brand"]
        description = request.POST["description"]
        image = request.FILES.get("image", None)

        sustainable_material = False
        if material in ['COTTON', 'LINEN', 'BAMBOO', 'R-POLYESTER', 'LYOCELL', 'MODAL']:
            sustainable_material = True


        colour = None
        if image:
            
            color_thief = ColorThief(image)
            colour = color_thief.get_color(quality=10)  
          

        
        
        clothing_item = ClothingItem.objects.create(
            name=item_name,
            second_hand=is_second_hand,
            category =category,
            material = material,
            colour = colour,
            size = size,
            purchase_date = purchase_date,
            price = price,
            brand = brand,
            sustainable_material=sustainable_material,
            description = description,
            image=image,
            user=request.user

        )

        
        return HttpResponseRedirect(reverse("webapp:home"))

def viewitem(request):
    items = ClothingItem.objects.filter(user=request.user)  
    context ={'items': items }
    return render(request, 'webapp/viewitem.html',context)


def itemdetail(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    context = {
        'item': item,
    }
    
    
    return render(request, 'webapp/itemdetail.html', context)

def goals(request):
     if request.method == "GET":
        context = {}
        return render(request, "webapp/goals.html", context)


def deleteitem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    if request.method == 'GET':
        item.delete()
        return redirect('webapp:viewitem')
    

def edititem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    categories = ClothingItem.CATEGORY_CHOICES  
    materials = ClothingItem.MATERIAL_CHOICES  

    if request.method == "POST":
       
        item.name = request.POST["name"]
        item.second_hand = request.POST["second_hand"] == "true"
        item.category = request.POST["category"]
        item.material = request.POST["material"]
        item.colour = request.POST["colour"]
        item.size = request.POST["size"]
        item.purchase_date = request.POST["purchase_date"] if request.POST["purchase_date"] else None
        item.price = request.POST["price"]
        item.brand = request.POST["brand"]
        item.description = request.POST["description"]
        item.image = request.FILES.get("image", item.image)  

       
        sustainable_material = item.material in ['COTTON', 'LINEN', 'BAMBOO', 'R-POLYESTER', 'LYOCELL', 'MODAL']
        item.sustainable_material = sustainable_material
        
        
        item.save()

      
        return redirect('webapp:viewitem')

    context = {
        'item': item,
        'categories': categories,
        'materials': materials
    }
    return render(request, "webapp/edititem.html", context)

    