from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin

class ClothingItem(models.Model):
    CATEGORY_CHOICES = [
        ('TOP', 'Top'),
        ('BOTTOM', 'Bottom'),
        ('FOOTWEAR', 'Footwear'),
        ('OUTERWEAR', 'Outerwear'),
        ('ACCESSORY', 'Accessory'),
    ]

    MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),


    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ClothingItems')
    name = models.CharField(max_length=100)
    second_hand = models.BooleanField(default=False)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    material = models.CharField(max_length=20, choices=MATERIAL_CHOICES, blank=True, null=True)
    colour = models.CharField(max_length=30, blank=True, null=True)
    size = models.CharField(max_length=10, blank=True, null=True)
    purchase_date = models.DateField(blank = True, null = True)
    date_added = models.DateField(default=timezone.now)
    last_worn_date = models.DateField(blank=True, null=True)
    worn_count = models.PositiveIntegerField(default=0)
    price = models.DecimalField(max_digits=6, decimal_places=2, blank=True, null=True)
    brand = models.CharField(max_length=100, blank=True, null=True)
    sustainable_material = models.BooleanField(default=False, blank =True, null = True)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='clothing_items/', blank=True, null=True)
    wash_count = models.PositiveIntegerField(default = 0)


    def wear(self): 
        self.worn_count += 1
        self.last_worn_date = timezone.now()
        self.save()
    
    def wash(self):
        self.wash_count += 1
        self.save()

class Outfit(models.Model):
    name = models.CharField(max_length=100)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='outfit')
    clothing_item = models.ForeignKey(ClothingItem, on_delete=models.CASCADE, related_name="outfit")
    

    def __str__(self):
        return self.name
    

class Outfit_Schedule(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='outfit_schedule')
    outfit = models.ForeignKey(Outfit, on_delete=models.CASCADE, related_name='outfit_schedule')
    weather_condition = models.CharField(max_length=100)
    outfit_date = models.DateField
    OCCASION_CHOICES = [
        ('CASUAL', 'Casual'),
        ('FORMAL', 'Formal'),
        ('PARTY', 'Party'),
        ('WORK', 'Work'),
        ('HOLIDAY', 'Holiday'),
    ]
    
    occasion = models.CharField(max_length=20, choices=OCCASION_CHOICES, blank=True, null=True)

class Sustainability_Metrics(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sustainability_metrics')
    clothing_item = models.ForeignKey(ClothingItem, on_delete=models.CASCADE, related_name='sustainability_metrics')
    carbon_savings = models.PositiveIntegerField(default=0)
    item_usage_percentage = models.PositiveIntegerField(default=0)
    second_hand_percentage = models.PositiveIntegerField(default=0)
    susatainable_score = models.PositiveIntegerField(default=0)
    reportDate = models.DateField

class Goal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='goal')
    description = models.CharField(max_length = 100)
    start_date = models.DateField
    end_date = models.DateField
    STATUS_CHOICES = [
        ('ONGOING', 'Ongoing'),
        ('COMPLETE', 'Complete'),
        ('FAILED', 'Failed'),

    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, blank=True, null=True)


class Points(models.Model):
     user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='points')
     points_total = models.PositiveIntegerField(default=0) 
     points_earned = models.PositiveIntegerField(default=0)  
     date_earned = models.DateField(auto_now_add=True)        
     points_reason = models.CharField(max_length=255)

     def earn_points(self, amount, reason):
        
        self.points_earned += amount
        self.points_total += amount
        self.points_reason = reason
        self.save() 

class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlist')
    item_name = models.CharField(max_length=100)  
    source = models.URLField(blank=True, null=True)  
    material = models.CharField(max_length=50, blank=True, null=True)  
    price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    susatainable_rating = models.PositiveIntegerField(default=0)









    



 