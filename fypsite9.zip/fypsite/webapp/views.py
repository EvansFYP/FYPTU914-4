from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.utils.dateparse import parse_datetime
from django.contrib import admin
from colorthief import ColorThief
import requests
from django.db.models import Sum
from django.http import JsonResponse
import requests
from datetime import date, timedelta, datetime 
from django.utils import timezone
import webcolors
import matplotlib
import numpy as np
from sklearn.neighbors import NearestNeighbors
from skimage.color import rgb2lab
import os
import kagglehub

from fypsite import settings
from .models import ClothingItem
from .models import Outfit, Outfit_Schedule
from .models import Sustainability_Metrics
from .models import Goal
from .models import Point
from .models import WorkSchedule
from .models import Product
from .models import Purchase
from .models import Wishlist
from django.utils.timezone import now
import requests
from bs4 import BeautifulSoup
import re
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from urllib.parse import urlparse
import json
from collections import OrderedDict
from .models import UserProfile
from django.db.models.signals import post_save
from django.dispatch import receiver








os.environ['KAGGLE_USERNAME'] = 'evanweldon'
os.environ['KAGGLE_KEY'] = 'd1385dc18ea673a0a35bdf000f61e175'









CATEGORY_CHOICES = [
    ('TOP', 'Top'),
    ('BOTTOM', 'Bottom'),
    ('FOOTWEAR', 'Footwear'),
    ('OUTERWEAR', 'Outerwear'),
    ('ACCESSORY', 'Accessory'),
]

MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('R-WOOL', 'Recycled Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),
        ('OTHER', 'Other'),

    ]



@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        # Create a new UserProfile only if it doesn't exist
        UserProfile.objects.create(user=instance)
    else:
        # Try to get the existing profile, if not, create one
        profile, created = UserProfile.objects.get_or_create(user=instance)
        if not created:
            # Update the profile if it already exists 
            profile.save()


def signup(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signup.html", context)
    else:
        user = User.objects.create_user(
            username=request.POST["Username"],
            password=request.POST["Password"]
        )
        
        return HttpResponseRedirect(reverse("webapp:signin"))

def signin(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signin.html", context)
    else:
        user = authenticate(
            request,
            username=request.POST["Username"],
            password=request.POST["Password"]
        )

        if user is not None:
            login(request, user)
            print("logged in", user)
            return HttpResponseRedirect(reverse("webapp:home"))
        


def get_lat_lon():
    
    url = "http://ip-api.com/json/"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        if data["status"] == "success":
            latitude = round(data["lat"], 6)  
            longitude = round(data["lon"], 6)
            return latitude, longitude
        else:
            print("Error retrieving city-based location data.")
            return None, None, None
    except requests.RequestException as e:
        print(f"Error retrieving geolocation data: {e}")
        return None, None, None


lat, lon = get_lat_lon()
print(f"Latitude: {lat}, Longitude: {lon}")



def fetch_weather_forecast(latitude, longitude):
  
    api_key = "GBWM6TUL5HEYSSSTUSAEFPVH6" #my api key for Visual Crossing
    weather_url = (
        f"https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast"
        f"?key={api_key}&unitGroup=metric&contentType=json&aggregateHours=24&locations={latitude},{longitude}"
    )
    weather_response = requests.get(weather_url)#get request to api 
    weather_data = weather_response.json() #convert to json format 

    # Extract the forecast for the next 7 days
    location_key = f"{latitude},{longitude}"
    forecast_data = weather_data['locations'][location_key]['values'][:7]

    # Convert timestamps to datetime objects
    for day in forecast_data:
        timestamp = day['datetime']
        day['datetime'] = datetime.fromtimestamp(timestamp / 1000)  #changes timestamps to seconds
    

    return forecast_data





def homeview(request):
    if request.method == "GET":
        latitude, longitude = get_lat_lon() #retrieve latitude and longitude 
        
        
        forecast_data = fetch_weather_forecast(latitude, longitude) #pass it to the weather function and retrieve forecast data

        user = request.user 

       
        scheduled_outfits = schedule_outfits_for_forecast(user, forecast_data) # pass the data and user to the outfit scheduler 


        #pass both as context to the home page
        context = {
            'outfits_for_week': scheduled_outfits,
            'forecast': forecast_data,
        }
        return render(request, 'webapp/home.html', context)

    return render(request, 'webapp/home.html', {'error': 'Invalid request method.'})




def get_colour_name(rgb_triplet):
    #list of common human color names and their hex values
    myColors = {
        "red"     : "#ff0000",
        "orange"  : "#ffa500",
        "yellow"  : "#ffff00",
        "green"   : "#008000",
        "blue"    : "#0000ff",
        "magenta" : "#ff00ff",
        "purple"  : "#800080",
        "coral"   : "#ff7f50",
        "maroon"  : "#800000",
        "navy"    : "#000080",
        "cyan"    : "#00ffff",
        "gold"    : "#ffd700",
        "lime"    : "#00ff00",
        "jade"    : "#00a36c",
        "olive"   : "#808000",
        "gray"    : "#808080",
        "cream"   : "#fffdd0",
        "white"   : "#ffffff",
        "black"   : "#000000",
        "teal"    : "#008080",
        "sky blue": "#87CEEB",
        "brown"   : "#a52a2a"
    }
    
    # Find the closest color match based the passed RGB values
    min_colours = {}
    for name, hex_val in myColors.items():
        r_c, g_c, b_c = webcolors.hex_to_rgb(hex_val)
        rd = (r_c - rgb_triplet[0]) ** 2
        gd = (g_c - rgb_triplet[1]) ** 2
        bd = (b_c - rgb_triplet[2]) ** 2
        min_colours[(rd + gd + bd)] = name
    
    return min_colours[min(min_colours.keys())]

    
 
    
def additem(request):
    user = request.user
    profile = UserProfile.objects.get(user=user)
    
    if request.method == "GET":
        context = {
            'categories': CATEGORY_CHOICES, 
            'material': MATERIAL_CHOICES,
            'COMMON_MATERIALS': COMMON_MATERIALS,
            'preferred_size': profile.preferred_size,
            'preferred_footwear_size': profile.preferred_footwear_size,
            'footwear_size_system': profile.footwear_size_system,
        }
        return render(request, "webapp/additem.html", context)
      
    else:
        # Basic field processing
        item_name = request.POST["name"]
        second_hand = request.POST["second_hand"]
        is_second_hand = second_hand == "true"
        category = request.POST["category"]
        subcategory = request.POST["subcategory"] 
        size = request.POST["size"]
        purchase_date = request.POST["purchase_date"] or None
        brand = request.POST["brand"]
        description = request.POST["description"]
        image = request.FILES.get("image", None)

        # Process materials
        materials = request.POST.getlist('materials[]')
        percentages = request.POST.getlist('percentages[]')

        # Combine into a formatted string
        material_components = []
        for mat, perc in zip(materials, percentages):
            material_components.append(f"{mat} {perc}%")
        material_string = ", ".join(material_components)

        # Try parsing with search_materials_with_percentages as fallback
        parsed = search_materials_with_percentages(material_string)
        if parsed["materials"] != "Not found" and parsed["total_percentage"] == 100:
            material_string = parsed["materials"]
            material_sustainability_score = parsed["sustainability_score"]
        else:
            # Calculate weighted score manually
            material_sustainability_score = 0
            for mat, perc in zip(materials, percentages):
                mat_score = MATERIAL_SUSTAINABILITY_SCORES.get(mat.upper(), MATERIAL_SUSTAINABILITY_SCORES["OTHER"])
                material_sustainability_score += mat_score * (int(perc) / 100)

        sustainable_material = material_sustainability_score <= 40

        text_for_color = f"{item_name} {description}"
        colour = extract_color_by_keywords(text_for_color)
        # Detect colour from image
        if colour == "Not found" and image:
            try:
                color_thief = ColorThief(image)
                dominant_rgb = color_thief.get_color(quality=10)
                colour = get_colour_name(dominant_rgb)
            except:
                pass  # Handle cases where color detection fails

        # Calculate carbon impact
        carbon_used, carbon_savings = calculate_carbon_impact(material_string, is_second_hand)

        # Create ClothingItem
        clothing_item = ClothingItem.objects.create(
            name=item_name,
            second_hand=is_second_hand,
            category=category,
            subcategory=subcategory,
            material=material_string,
            colour=colour,
            size=size,
            purchase_date=purchase_date,
            brand=brand,
            sustainable_material=sustainable_material,
            material_sustainability_score=material_sustainability_score,
            carbon_savings=carbon_savings,
            carbon_used=carbon_used,
            description=description,
            image=image,
            user=request.user
        )

        # Update goals
        goals = Goal.objects.filter(user=request.user, status='ONGOING')
        for goal in goals:
            if goal.goal_type == 'second_hand' and is_second_hand:
                goal.progress += 1
            elif goal.goal_type == 'sustainable_choices' and sustainable_material:
                goal.progress += 1

            if goal.progress >= goal.improvement_target:
                complete_goal(goal)

            goal.save()

        return HttpResponseRedirect(reverse("webapp:edititem", kwargs={"item_id": clothing_item.id}))
        

    
MATERIAL_CARBON_EMISSIONS = {
    # Best (Lowest Emissions) 
    'LYOCELL': 5,        # Closed-loop process
    'HEMP': 3.5,         # Estimated (low water, no pesticides)
    'R-WOOL': 7,         # Recycled reduces impact
    'BAMBOO': 6,         # Sustainably processed
    'LINEN': 4.5,        # Low carbon, biodegradable
    'R-COTTON': 5.6,     # Estimated (30% lower than conventional cotton)
    'R-POLYESTER': 3,    # Recycled halvs polyester’s footprint
    'MODAL': 6,          # Better than viscose
    
    # Moderate
    'ORGANIC_COTTON': 7, # Estimated (similar to conventional but no pesticides)
    'WOOL': 14,          # High methane emissions
    'DENIM': 10,         # Water-intensive dyeing
    'COTTON': 8,         # Conventional (water/pesticide-heavy)
    'POLYESTER': 6.4,    # Fossil-fuel-based
    'NYLON': 7.3,        # energy-intensive
    'RAYON': 8,          # (chemical-heavy)
    'VISCOSE': 8,        # Similar to rayon
    
    # High Emissions
    'LEATHER': 15,       # Livestock + tanning
    'ACRYLIC': 15,       # High pollution
    'POLYAMIDE': 7.3,    # Same as nylon
    'SYNTHETIC': 14,     # Generic worst-case
    'SPANDEX': 14,       # Non-recyclable
    'ELASTANE': 14,      # Same as spandex
    'OTHER': 10          # Default assumption
}

def calculate_carbon_impact(material_text, second_hand):
    total_carbon = 0
    total_savings = 0

    if not material_text.strip():
        default_carbon = 10
        total_carbon = default_carbon
        if second_hand:
            total_savings = default_carbon  # Full savings if second-hand
        return round(total_carbon, 2), round(total_savings, 2)

    try:
        material_components = material_text.split(", ")
        for component in material_components:
            mat, perc = component.split(" ")
            perc = int(perc.replace('%', ''))
            
            mat_upper = mat.upper()
            carbon_per_kg = MATERIAL_CARBON_EMISSIONS.get(mat_upper, 10)

            carbon = carbon_per_kg * (perc / 100)
            total_carbon += carbon

            if second_hand:
                total_savings += carbon
            elif mat_upper.startswith("R-"):
                total_savings += carbon * 0.5

    except Exception as e:
        print(f"Carbon calc error: {e}")
        total_carbon = 10
        if second_hand:
            total_savings = 10

    return round(total_carbon, 2), round(total_savings, 2)

def viewitem(request):
    items = ClothingItem.objects.filter(user=request.user)  
    context ={'items': items }
    return render(request, 'webapp/viewitem.html',context)


def itemdetail(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)

    context = {
        'item': item,
    }
    
    
    return render(request, 'webapp/itemdetail.html', context)

def goals(request):
     if request.method == "GET":
        context = {}

        points = Point.objects.filter(user=request.user).last()
     if points:
                points_current = points.points_current
     else:
                points_current = 0 

     context['points_current'] = points_current

     return render(request, "webapp/goals.html", context)


def deleteitem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    if request.method == 'GET':
        item.delete()
        return redirect('webapp:viewitem')
    

def parse_material_string(material_str):
    materials = []
    parts = material_str.split(',')
    for part in parts:
        match = re.match(r'\s*(\w[\w\s]*)\s+(\d+)%\s*', part.strip())
        if match:
            name, percentage = match.groups()
            materials.append({'name': name.strip(), 'percentage': percentage.strip()})
    return materials


def edititem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)

    categories = ClothingItem.CATEGORY_CHOICES  
    materials = ClothingItem.MATERIAL_CHOICES  
    subcategories = ClothingItem.get_subcategories(item.category)

    if request.method == "POST":
        item.name = request.POST["name"]
        item.second_hand = request.POST["second_hand"] == "true"
        item.category = request.POST["category"]
        item.subcategory = request.POST['subcategory']

        # Build material string from lists
        names = request.POST.getlist("material_name")
        percentages = request.POST.getlist("material_percentage")
        material_str = ", ".join([
            f"{name.strip()} {perc.strip()}%" for name, perc in zip(names, percentages)
        ])
        item.material = material_str

        item.colour = request.POST["colour"]
        item.size = request.POST["size"]
        item.purchase_date = request.POST["purchase_date"] if request.POST["purchase_date"] else None
        item.brand = request.POST["brand"]
        item.description = request.POST["description"]
        item.image = request.FILES.get("image", item.image)  

        if item.material_sustainability_score <= 40:
            item.sustainable_material = True

        item.save()
        return redirect('webapp:viewitem')

    # Parse material breakdown to pre-fill material form fields
    material_breakdown = parse_material_string(item.material)

    context = {
        'item': item,
        'categories': categories,
        'materials': materials,
        'subcategories': subcategories,
        'material_breakdown': material_breakdown,
    }

    return render(request, "webapp/edititem.html", context)



def select_outfit_based_on_weather(temp, conditions, user, outfit_date, occasion=None):
    day_name = outfit_date.strftime("%A")  # Use the forecasted day's name

    work_schedule = WorkSchedule.objects.filter(user=user).first()

    if work_schedule:
        work_days_list = (
            work_schedule.work_days if isinstance(work_schedule.work_days, list)
            else work_schedule.work_days.split(",")
        )

        print(f"Checking work schedule - Date: {outfit_date}, Day: {day_name}, Work Days: {work_days_list}, Work Type: {work_schedule.work_type}")

        if day_name in work_days_list:
            occasion = work_schedule.work_type  # Set occasion to WORK_FORMAL or WORK_CASUAL from Work Model

    # Determine outfit based on weather if it's not a workday
    if not occasion:
        if temp > 20:
            occasion = "HOT"
        elif 10 <= temp <= 20:
            occasion = "MILD"
        else:
            occasion = "COLD"

        if "Rain" in conditions:
            occasion = "RAINY"

    subcategory_map = {
        "HOT": {
            "BASE_TOP": ["T-SHIRT", "TANK_TOP", "CROP_TOP", "BLOUSE", "TUBE_TOP", "DRESS"],
            "BOTTOM": ["SHORTS", "SKIRT"],
            "FOOTWEAR": ["SANDALS", "SNEAKERS", "LOAFERS"],
            "ACCESSORY": ["SUNGLASSES", "HAT"]
        },
        "MILD": {
            "BASE_TOP": ["T-SHIRT", "BLOUSE", "LONG_SLEEVE",],
            "MID_LAYER": ["SWEATER", "HOODIE", "FLANNEL", "CARDIGAN"],
            "BOTTOM": ["JEANS", "JOGGERS", "LEGGINGS", "CHINOS"],
            "FOOTWEAR": ["SNEAKERS", "LOAFERS", "BOOTS"],
            "OUTER_LAYER": ["LIGHT_JACKET", "JACKET", "WINDBREAKER"],
            "ACCESSORY": ["WATCH"]
        },
        "COLD": {
            "BASE_TOP": ["LONG_SLEEVE", "TURTLE", "T-SHIRT"],
            "MID_LAYER": ["SWEATER", "HOODIE", "FLANNEL", "CARDIGAN"],
            "BOTTOM": ["JEANS", "JOGGERS", "LEGGINGS", "CHINOS"],
            "FOOTWEAR": ["BOOTS", "SNEAKERS"],
            "OUTER_LAYER": ["COAT", "JACKET"],
            "ACCESSORY": ["GLOVES", "SCARF", "HAT"]
        },
        "RAINY": {
            "BASE_TOP": ["LONG_SLEEVE", "TURTLE", "T-SHIRT"],
            "MID_LAYER": ["SWEATER", "HOODIE", "FLANNEL", "CARDIGAN"],
            "BOTTOM": ["JEANS", "JOGGERS", "LEGGINGS", "CHINOS"],
            "FOOTWEAR": ["BOOTS", "SNEAKERS"],
            "OUTER_LAYER": ["COAT", "JACKET"],
            "ACCESSORY": ["GLOVES", "SCARF", "HAT"]
        },
        "WORK_FORMAL": {
            "BASE_TOP": ["SHIRT", "BLOUSE"],
            "MID_LAYER": ["BLAZER", "WAIST_COAT"],
            "BOTTOM": ["DRESS_PANTS", "PENCIL_SKIRT"],
            "FOOTWEAR": ["DRESS_SHOES", "HEELS"],
            "OUTER_LAYER": ["COAT", "JACKET"],
            "ACCESSORY": ["TIE", "WATCH", "BELT"]
        },
        "WORK_CASUAL": {
            "BASE_TOP": ["T-SHIRT", "POLO", "SHIRT", "BLOUSE"],
            "MID_LAYER": ["CARDIGAN", "FLANNEL"],
            "BOTTOM": ["CHINOS", "PENCIL_SKIRT", "JEANS"],
            "FOOTWEAR": ["LOAFERS", "SNEAKERS"],
            "OUTER_LAYER": ["LIGHT_JACKET"],
            "ACCESSORY": ["WATCH", "BELT", "SCARF"]
        }
    }

    selected_subcategories = subcategory_map.get(occasion, {})
    outfit_items = []
    used_layers = set()  # Track layers to ensure each layer has at least one item

    # Select clothing items for each category
    for layer, subcategories in selected_subcategories.items():
        print(f"Selecting item for {layer}") 
        items = user.clothing_items.filter(
            subcategory__in=subcategories
        ).order_by('worn_count', 'last_worn_date')

        for item in items:
            if layer not in used_layers:  # Check if the layer is already used
                outfit_items.append(item)
                used_layers.add(layer)  # Mark this layer as used
                break  # Stop after adding one item from this layer

    # Ensure there are at least 5 different layers/items
    if len(used_layers) >= 5:
        outfit = Outfit.objects.create(name=f"Outfit for {user.username}", user=user)
        outfit.clothing_items.set(outfit_items)
        outfit.save()
        return outfit
    else:
        print(f"User {user.username} does not have enough items for an outfit.")
        return None



def schedule_outfits_for_forecast(user, forecast_data):  
    outfits_for_week = []

    if not user.clothing_items.exists():
        print(f"No clothing items for user {user.username}.")
        return {'error': 'No clothing items available for this user.'}

    for i, day_forecast in enumerate(forecast_data):
        temp = day_forecast['temp']
        conditions = day_forecast['conditions']
        outfit_date = date.today() + timedelta(days=i)
        
     

        # Check if an outfit is already scheduled
        outfit_schedule = Outfit_Schedule.objects.filter(user=user, outfit_date=outfit_date).first()

        if outfit_schedule:
            print(f"Outfit already scheduled for {outfit_date}.")
            outfits_for_week.append(outfit_schedule.outfit)

           
        else:
            print(f"No outfit scheduled for {outfit_date}. Generating new outfit.")

            
            outfit = select_outfit_based_on_weather(temp, conditions, user, outfit_date)

            if outfit:
                Outfit_Schedule.objects.create(
                    user=user,
                    outfit=outfit,
                    weather_condition=f"{temp}°C, {conditions}",
                    outfit_date=outfit_date
                )
                print(f"Outfit scheduled for {outfit_date}.")
                outfits_for_week.append(outfit)

    return outfits_for_week




def outfit_detail(request, outfit_date):
    user = request.user
    outfit_schedule = get_object_or_404(Outfit_Schedule, user=user, outfit_date=outfit_date)
    outfit = outfit_schedule.outfit

    # Prepare a list of items
    available_items_by_item = []
    for item in outfit.clothing_items.all():
        #should only be items owned by the user
        replacements = ClothingItem.objects.filter(category=item.category, user=user).exclude(id=item.id)
        available_items_by_item.append((item, replacements))

    return render(request, 'webapp/outfit_detail.html', {
        'outfit': outfit,
        'outfit_schedule': outfit_schedule,
        'date': outfit_date,
        'available_items_by_item': available_items_by_item
    })



def calculate_reusability_score(worn_count, time_in_wardrobe):
    # Calculate the score as a ratio of worn_count to time_in_wardrobe
    if time_in_wardrobe > 0:
        score = (worn_count / time_in_wardrobe) * 100
        # Ensure the score doesn't exceed 100
        return min(score, 100)
    return 0


def calculate_sustainability_metrics(request):
    if request.user.is_authenticated:
        user = request.user

        # Fetch all clothing item
        clothing_items = ClothingItem.objects.filter(user=user)

        if not clothing_items.exists():
            return render(request, 'webapp/error_page.html', {'error': 'No clothing items found for the user.'})

        
        total_material_score = 0
        total_carbon_savings = 0
        total_carbon_used = 0
        second_hand_items = 0
        total_items = clothing_items.count()
        total_reusability_score = 0

        # Loop through clothing items
        for item in clothing_items:
            total_material_score += item.material_sustainability_score
            total_carbon_savings += item.carbon_savings
            total_carbon_used += item.carbon_used

            if item.second_hand:
                second_hand_items += 1

            # Calculate time in wardrobe
            time_in_wardrobe = (date.today() - item.date_added).days if item.date_added else 0

            # Calculate the reusability score
            total_reusability_score += calculate_reusability_score(item.worn_count, time_in_wardrobe)

        # Calculate percentages and averages
        second_hand_percentage = (second_hand_items / total_items) * 100 if total_items > 0 else 0
        avg_material_score = total_material_score / total_items if total_items > 0 else 0
        avg_reusability_score = total_reusability_score / total_items if total_items > 0 else 0
        print(f"Total Items: {total_items}")
        print(f"Total Material Score: {total_material_score}")
        print(f"Total Reusability Score: {total_reusability_score}")
        print(f"Total Second Hand Items: {second_hand_items}")
        print(f"Second Hand Percentage: {second_hand_percentage}%")
        print(f"Average Material Score: {avg_material_score}")
        print(f"Average Reusability Score: {avg_reusability_score}")

        # Final sustainable score 
        sustainable_score = int(
            (100 - avg_material_score) * 0.4 + + avg_reusability_score * 0.2 + second_hand_percentage * 0.4
        )  

       
        today = now().date()

        # Check if a Sustainability_Metrics object already exists for today
        metrics, created = Sustainability_Metrics.objects.update_or_create(
            user=user,
            reportDate=today,
            defaults={
                'carbon_savings': total_carbon_savings,
                'item_usage_percentage': avg_reusability_score,  
                'second_hand_percentage': second_hand_percentage,
                'sustainable_score': sustainable_score,
                'carbon_used' : total_carbon_used,
            }
        )

        # Pass as context  to the report.html
        context = {
            'carbon_savings': metrics.carbon_savings,
            'carbon_used' : metrics.carbon_used,
            'item_usage_percentage': metrics.item_usage_percentage,
            'second_hand_percentage': metrics.second_hand_percentage,
            'sustainable_score': metrics.sustainable_score,
            'report_date': metrics.reportDate,
            'status': 'created' if created else 'updated',
        } 

        return render(request, 'webapp/sustainability_report.html', context)

    return render(request, 'webapp/error_page.html', {'error': 'User not authenticated.'})




def create_goal(request):
    user = request.user
    if request.method == 'POST':
        

        end_date = request.POST.get('end_date')
        goal_type = request.POST.get('goal_type')
        improvement_target = request.POST.get('improvement_target', None)
        second_hand_target = request.POST.get('second_hand_target', None)
        clothing_recycling_target = request.POST.get('clothing_recycling_target', None)
        sustainable_choices_target = request.POST.get('sustainable_choices_target', None)


        target = None

        initial_score = 0 
        if goal_type == 'sustainable_scores':
            target = improvement_target
            sustainability_score = Sustainability_Metrics.objects.filter(user=user).first()
            initial_score = sustainability_score.sustainable_score if sustainability_score else 0

        elif goal_type == 'second_hand':
            target = second_hand_target
        elif goal_type == 'clothing_recycling':
            target = clothing_recycling_target
        elif goal_type == 'sustainable_choices':
            target = sustainable_choices_target
        
        
        
        start_date = timezone.now().date()

        goal_descriptions = {
            'carbon_savings': "This goal focuses on improving your carbon footprint by making environmentally conscious choices.",
            'second_hand': "This goal encourages acquiring second-hand items to reduce waste and support sustainable consumption.",
            'clothing_recycling': "This goal promotes recycling, donating or reselling clothing items to extend their lifecycle and reduce landfill waste.",
            'sustainable_choices': "This goal aims to acquire sustainable items that align with eco-friendly practices."
        }

       
        description = goal_descriptions.get(goal_type, "No description available for this goal type.")
      
        goal = Goal.objects.create(
            user=request.user,
            description=description,
            start_date=start_date,
            end_date=end_date,
            goal_type=goal_type,
            improvement_target=target,
            initial_score=initial_score,
            
        )

        
        return redirect('webapp:goals_list')  

    else:
     
    
        return render(request, 'webapp/goals.html')
    
def goals_list(request):
  
    goals = Goal.objects.filter(user=request.user)

    now = timezone.now().date()
   
    for goal in goals:##loop through goals and check if any goals have expired if they have set status to failed
        
        if goal.end_date < now and goal.status != 'COMPLETE':
            goal.status = 'FAILED'
            goal.save()
    
    return render(request, 'webapp/goals_list.html', {'goals': goals})

def cancel_goal(request, goal_id):
    
    goal = get_object_or_404(Goal, id=goal_id)

    
    if request.method == 'POST':
        status = request.POST.get('status')

        if status == 'CANCELLED':
            
            goal.delete()
            return redirect('webapp:goals_list')  
        
     
        goal.status = status
        goal.save()

        return redirect('webapp:goals_list')



def check_goal_completion(user):
    today = now().date()
    goals = Goal.objects.filter(user=user, status='ONGOING')


    sustainability = Sustainability_Metrics.objects.filter(user=user).first()

    if not sustainability:
        return  

    for goal in goals:
        if goal.goal_type == 'carbon_savings':
        

           initial_score = goal.initial_score 

           current_savings = sustainability.carbon_savings  
        
      
           target_savings = initial_score + goal.improvement_target

       
        if current_savings >= target_savings:
            complete_goal(goal)

        goal.save()

def verify_goal_listing(request, goal_id):
    goal = get_object_or_404(Goal, id=goal_id, user=request.user)
    
    if request.method != 'POST':
        return redirect('webapp:goals_list')

    listing_url = request.POST.get('listing_url', '').strip()
    if not listing_url:
        messages.error(request, "Please enter a valid URL", extra_tags=goal_id)
        return redirect('webapp:goals_list')

    # Verification checks
    if listing_url in goal.verification_urls:
        messages.warning(request, "This listing was already verified", extra_tags=goal_id)
        return redirect('webapp:goals_list')
 
    try:
        response = requests.get(listing_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
        if goal.verification_code.lower() not in response.text.lower():
            messages.error(request, "Verification code not found", extra_tags=goal_id)
            return redirect('webapp:goals_list')

        # Update and complete goal if needed
        goal.verification_urls.append(listing_url)
        goal.progress += 1
        
        if hasattr(goal, 'improvement_target') and goal.progress >= goal.improvement_target:
            complete_goal(goal)
            messages.success(request, "Goal completed!", extra_tags=goal_id)
        else:
            messages.success(request, "Listing verified!", extra_tags=goal_id)
        
        goal.save()

    except Exception as e:
        messages.error(request, f"Verification failed: {str(e)}", extra_tags=goal_id)
    
    return redirect('webapp:goals_list') 
  
 
def complete_goal(goal):
    goal.status = 'COMPLETE'
    goal.save()

    # Retrieve the last point record for the user
    last_point = Point.objects.filter(user=goal.user).order_by('-date_earned').first()
    
    if last_point:
        print(f"User: {goal.user.username}, Last Point Total: {last_point.points_total}, Last Point Current: {last_point.points_current}, Last Point Coins: {last_point.coins}")
    else:
        print(f"User: {goal.user.username} has no previous point records.")
    
    previous_total = last_point.points_total if last_point else 0
    previous_current = last_point.points_current if last_point else 0
    previous_coins = last_point.coins if last_point else 0

    # Retrieve sustainability metrics to determine the multiplier
    sustainability_metrics = goal.user.sustainability_metrics.order_by('-reportDate').first()
    
    if sustainability_metrics:
        sustainability_score = sustainability_metrics.sustainable_score
        print(f"Sustainability Score: {sustainability_score}")
    else:
        sustainability_score = 0
        print("No sustainability metrics found, score set to 0.")
    
    if sustainability_score >= 90:
        multiplier = 2.0
    elif sustainability_score >= 75:
        multiplier = 1.5
    elif sustainability_score >= 50:
        multiplier = 1.2
    else:
        multiplier = 1.0

    print(f"Multiplier: {multiplier}")

    base_points = 5
    extra_points = 0

    # Calculate extra points based on the goal type and improvement target
    if goal.goal_type == 'carbon_savings':
        if goal.improvement_target >= 25:
            extra_points = 50
        elif goal.improvement_target >= 20:
            extra_points = 25
        elif goal.improvement_target >= 15:
            extra_points = 15
    elif goal.goal_type == 'clothing_recycling':
        if goal.improvement_target >= 20:
            extra_points = 50
        elif goal.improvement_target >= 10:
            extra_points = 25
        elif goal.improvement_target >= 5:
            extra_points = 15
    elif goal.goal_type == 'second_hand':
        if goal.improvement_target >= 10:
            extra_points = 50
        elif goal.improvement_target >= 5:
            extra_points = 25
        elif goal.improvement_target >= 3:
            extra_points = 15
    elif goal.goal_type == 'sustainable_choices_section':
        if goal.improvement_target >= 10:
            extra_points = 50
        elif goal.improvement_target >= 5:
            extra_points = 25
        elif goal.improvement_target >= 3:
            extra_points = 15

    print(f"Base Points: {base_points}, Extra Points: {extra_points}")

    # Apply the multiplier
    final_points = int((base_points + extra_points) * multiplier)
    print(f"Final Points (after multiplier): {final_points}")

    # Update points total and current points based on the previous values
    new_total = previous_total + final_points  # Add the new points to the total
    new_current = previous_current + final_points  # Add the new points to the current points

    print(f"New Total Points: {new_total}, New Current Points: {new_current}")

    # Handle coin calculation if points reach 100 or more
    thresholds_crossed = new_current // 100
    new_current = new_current % 100  # Reset the current points if it exceeds 100
    new_coins = previous_coins + (5 * thresholds_crossed)  # Coins are awarded for every 100 points

    print(f"New Coins: {new_coins}")

    # Create the new point record with the updated values
    Point.objects.create(
        user=goal.user,
        points_earned=final_points,
        points_total=new_total,
        points_current=new_current,
        coins=new_coins,
        points_reason="Completed goal"
    )

    print(f"Point record created for {goal.user.username}: {final_points} points, Total: {new_total}, Current: {new_current}, Coins: {new_coins}")

def work_schedule(request):
    user = request.user
    work_days_list = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

    work_schedule, _ = WorkSchedule.objects.get_or_create(user=user)
    profile, _ = UserProfile.objects.get_or_create(user=user)

    if request.method == "POST":
        works = request.POST.get("works") == "on"
        work_type = request.POST.get("work_type", None)
        work_days = request.POST.getlist("work_days")

        if not works:
            work_type = None
            work_days = []

        # Save work schedule
        work_schedule.works = works
        work_schedule.work_type = work_type
        work_schedule.work_days = ",".join(work_days)
        work_schedule.save()

        # Save user profile size settings
        profile.preferred_size = request.POST.get("preferred_size") or None
        profile.preferred_footwear_size = request.POST.get("preferred_footwear_size") or None
        profile.footwear_size_system = request.POST.get("footwear_size_system") or None
        profile.save()

        return redirect("webapp:home")

    selected_days = work_schedule.get_work_days_list()

    # These are the choices used in the template
    size_choices = [
        ("XS", "Extra Small"),
        ("S", "Small"),
        ("M", "Medium"),
        ("L", "Large"),
        ("XL", "Extra Large"),
        
    ]

    shoe_size_systems = [
        ("US", "US"),
        ("EU", "EU"),
        ("UK", "UK"),
    ]

    return render(
        request, 
        "settings.html",
        {
            "work_schedule": work_schedule,
            "selected_days": selected_days,
            "work_days_list": work_days_list,
            "profile": profile,
            "size_choices": size_choices,
            "shoe_size_systems": shoe_size_systems,
        },
    )


def swap_outfit(request, outfit_date, item_id):
    user = request.user
    item = get_object_or_404(ClothingItem, id=item_id, user=user)
    replacements = ClothingItem.objects.filter(user=user, category=item.category).exclude(id=item.id)
    
    return render(request, "webapp/swapoutfit.html", {
        "item": item, 
        "replacements": replacements, 
        "outfit_date": outfit_date
    })

def confirm_swap(request, item_id, replacement_id, outfit_date):
    user = request.user
    item = get_object_or_404(ClothingItem, id=item_id, user=user)
    replacement = get_object_or_404(ClothingItem, id=replacement_id, user=user)
    

    outfit_schedule = get_object_or_404(Outfit_Schedule, outfit_date=outfit_date, user=user)
    outfit = outfit_schedule.outfit
    
   
    outfit.clothing_items.remove(item)
    outfit.clothing_items.add(replacement)
    outfit.save()
    
    return redirect("webapp:outfit_detail", outfit_date=outfit_date)



def wear_outfit(request, outfit_date):
    user = request.user

    outfit_schedule = Outfit_Schedule.objects.filter(user=user, outfit_date=outfit_date).first()
     
    if outfit_schedule.outfit_date == date.today():

        for item in outfit_schedule.outfit.clothing_items.all():
            if  item.last_worn_date != date.today():
                 item.worn_count += 1
                 item.last_worn_date = date.today()
                 item.save()

    return render(request, "webapp/outfit_detail.html", {
        "outfit_date": outfit_date
    })



def leaderboard(request):


    leaderboard_users = (
        Point.objects.values('user', 'user__username')  
        .annotate(total_points=Sum('points_earned'))
        .order_by('-total_points')[:100]
    )

    context = {'leaderboard_users': leaderboard_users}
    return render(request, 'webapp/leaderboard.html', context)

def shop(request):
    if request.method == "GET":
        context = {}

        # get user's coins
        points = Point.objects.filter(user=request.user).last()
        coins = points.coins if points else 0
        context['coins'] = coins

        #get all products to show in shop
        products = Product.objects.all()
        context['products'] = products

        #get products the user has purchased
        purchased_products = Product.objects.filter(purchase__user=request.user)
        context['purchased_products'] = purchased_products

        return render(request, "webapp/shop.html", context)
    
from django.contrib import messages

def purchase_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    points = Point.objects.filter(user=request.user).last()
    coins = points.coins if points else 0  

    #check if user already purchased  product
    if Purchase.objects.filter(user=request.user, product=product).exists():
        messages.info(request, "You already own this product!")
        return redirect('webapp:shop')

    # Check if the user has enough coins
    if coins >= product.price:
        #minus the coins
        points.coins -= product.price
        points.save()  #update coins to the Point record

        # create purchase object and record it
        Purchase.objects.create(user=request.user, product=product)

        messages.success(request, f"Purchased {product.name}!")
    else:
        messages.error(request, "Not enough coins!")

    return redirect('webapp:shop')


def set_active_background(request, product_id=None):
    if product_id is None:
        # Reset to default
        Purchase.objects.filter(user=request.user, is_active_background=True).update(is_active_background=False)
        messages.success(request, "Default background set!")
        return redirect('webapp:shop')

    # Ensure product exists and is a background
    product = get_object_or_404(Product, id=product_id, category='background')

    # Ensure user has purchased product
    purchase = Purchase.objects.filter(user=request.user, product=product).first()
    if not purchase:
        messages.error(request, "You don't own this background!")
        return redirect('webapp:shop')

    # Set the selected background as active
    Purchase.objects.filter(user=request.user, is_active_background=True).update(is_active_background=False)  # Reset the previous active background
    purchase.is_active_background = True
    purchase.save()

    messages.success(request, f"{product.name} set as active background!")

    return redirect('webapp:shop')



MATERIAL_SUSTAINABILITY_SCORES = {
    # Best (Higg MSI 0-20)
    'LYOCELL': 10,       # Higg: 10 (TENCEL™ closed-loop)
    'HEMP': 15,          # Higg estimate: ~15 (low water, no pesticides)
    'R-WOOL': 20,        # Higg estimate: ~20 (recycled reduces impact)
    'BAMBOO': 25,        # Higg estimate: ~25 (sustainably processed)
    
    # Excellent (Higg MSI 20-40)
    'LINEN': 30,         # Higg: ~30 (low water, biodegradable)
    'R-POLYESTER': 35,   # Higg: ~35 (recycled but microplastics)
    'MODAL': 40,         # Higg: ~40 (better than viscose)
    
    # Moderate (Higg MSI 40-60)
    'ORGANIC_COTTON': 45, # Higg: ~45 (better than conventional)
    'WOOL': 50,          # Higg: ~50 (methane emissions)
    'DENIM': 55,         # Higg: ~55 (water-intensive)
    'COTTON': 60,        # Higg: 60 (conventional)
    
    # Poor (Higg MSI 60-100)
    'LEATHER': 70,       # Higg: ~70 (varies by tanning process)
    'NYLON': 75,         # Higg: 75 (energy-intensive)
    'POLYESTER': 80,
    'POLYAMIDE': 80,          # Higg: 80 (virgin polyester)
    'RAYON': 85,         # Higg: ~85 (chemical-heavy)
    'VISCOSE': 85,       # Higg: ~85 (similar to rayon)
    'ACRYLIC': 90,       # Higg: ~90 (high pollution)
    
    # Worst (Higg MSI 100+)
    'SYNTHETIC': 100,    # Generic worst-case
    'SPANDEX': 100,      # Higg: ~100 (non-recyclable)
    'ELASTANE': 100,     # Same as spandex
    'OTHER': 70,         # Default assumption (moderate-high impact)
}

def extract_product_view(request):
    product_info = None
    if request.method == "POST":
        url = request.POST.get("product_url")
        if url:
            try:
                product_info = extract_product_info(url)
                
                # If "add_to_wishlist" button was clicked
                if "add_to_wishlist" in request.POST:
                    return add_to_wishlist(request, product_info, url)
                
            except Exception as e:
                product_info = {"error": f"Could not extract product info: {str(e)}"}
    
    return render(request, "webapp/wishlist.html", {
        "product_info": product_info
    })



COMMON_MATERIALS = [
    "cotton", "polyester", "wool", "leather", "linen", "silk", "lyocell",
    "nylon", "denim", "rayon", "spandex", "acrylic", "viscose", "towelling", "elastane", "polyamide", "viscose"
]
COMMON_COLORS = [
    "black", "white", "grey", "blue", "red", "green", "gray",
    "yellow", "orange", "pink", "purple", "brown", "charcoal", "mauve", "beige", "cream", "khaki"
]

def extract_material_by_keywords(text):
    """Search the text for common material keywords."""
    found = []
    lower_text = text.lower()
    for material in COMMON_MATERIALS:
        if re.search(r'\b' + re.escape(material) + r'\b', lower_text):
            found.append(material.capitalize())
    return ", ".join(found) if found else "Not found"

def extract_color_by_keywords(text):
    """Search the text for common color keywords."""
    found = []
    lower_text = text.lower()
    for color in COMMON_COLORS:
        if re.search(r'\b' + re.escape(color) + r'\b', lower_text):
            found.append(color.capitalize())
    return ", ".join(found) if found else "Not found"

def extract_info_from_url(url):
    """Extract color and material info from the URL path."""
    parsed_url = urlparse(url)
    path = parsed_url.path
    words = path.replace("-", " ").replace("/", " ").lower().split()
    
    common_colors = set(COMMON_COLORS)
    common_materials = set(COMMON_MATERIALS)

    color = next((word for word in words if word in common_colors), "Not found")
    material = next((word for word in words if word in common_materials), "Not found")
    
    return {"color": color, "material": material}

def search_materials_with_percentages(text):
    """Extract material names with percentages that sum to exactly 100% without duplicates."""
    # First, find all possible material-percentage matches
    pattern = re.compile(
        r'(\d+)%\s*(' + '|'.join(re.escape(m) for m in COMMON_MATERIALS) + r')\b|'
        r'\b(' + '|'.join(re.escape(m) for m in COMMON_MATERIALS) + r')\s*(\d+)%',
        re.IGNORECASE
    )

    # Collect all unique material-percentage pairs
    all_matches = []
    seen_materials = set()
    
    for match in pattern.finditer(text):
        if match.group(1):  # Percentage before material
            percentage, material = int(match.group(1)), match.group(2).lower()
        else:  # Percentage after material
            material, percentage = match.group(3).lower(), int(match.group(4))
        
        # Skip duplicates (same material even with different percentages)
        if material not in seen_materials:
            seen_materials.add(material)
            all_matches.append((material, percentage))

    # Now try to find a combination that sums to exactly 100%
    selected_materials = {}
    current_sum = 0
    
    for material, percentage in all_matches:
        if current_sum + percentage <= 100:
            selected_materials[material.capitalize()] = percentage
            current_sum += percentage
            if current_sum == 100:
                break

    # If we didn't reach exactly 100%, try alternative combinations
    if current_sum != 100:
        # Try skipping earlier items to see if we can reach 100%
        for i in range(len(all_matches)):
            temp_selected = {}
            temp_sum = 0
            for j in range(i, len(all_matches)):
                material, percentage = all_matches[j]
                if temp_sum + percentage <= 100 and material.capitalize() not in temp_selected:
                    temp_selected[material.capitalize()] = percentage
                    temp_sum += percentage
                    if temp_sum == 100:
                        selected_materials = temp_selected
                        current_sum = temp_sum
                        break
            if current_sum == 100:
                break

    # Calculate sustainability score if we have materials
    sustainability_score = 0
    if selected_materials:
        total_percentage = sum(selected_materials.values())
        if total_percentage > 0:
            for material, percentage in selected_materials.items():
                material_score = MATERIAL_SUSTAINABILITY_SCORES.get(material.upper(), MATERIAL_SUSTAINABILITY_SCORES['OTHER'])
                sustainability_score += (percentage / total_percentage) * material_score

    # Format results
    formatted_materials = [f"{mat} {pct}%" for mat, pct in selected_materials.items()]
    
    return {
        "materials": ", ".join(formatted_materials) if formatted_materials else "Not found",
        "sustainability_score": round(sustainability_score, 2),
        "total_percentage": current_sum
    }

def extract_product_info(url): 
    # set up Selenium WebDriver
    chrome_options = Options()
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36")
    
    driver = webdriver.Chrome(options=chrome_options)
    driver.get(url)
    
    # wait for the page to load
    WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.TAG_NAME, "html")))

    page_source = driver.page_source
    soup = BeautifulSoup(page_source, "html.parser")
    
    # Extract title and product name
    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else "Not found"
    name = title.split(" | ")[0] if title != "Not found" else "Not found"
    
    # extract description
    description_tag = soup.find("meta", attrs={"name": "description"})
    description = description_tag["content"] if description_tag else "Not found"
    
    # extract image URL
    image = "Not found"
    try:
        
        landing_image = driver.find_element(By.CSS_SELECTOR, "img#landingImage")
        image = landing_image.get_attribute("src")
    except:
        try:
            # fallback to standard og image
            og_image = soup.find("meta", property="og:image")
            image = og_image["content"] if og_image else "Not found"
        except:
            pass
  
    
   
    materials = "Not found"
    
    if materials == "Not found":
        print("full search with percentage check.")
        all_elements = soup.find_all()
        all_text = " ".join(element.get_text(strip=True).lower() for element in all_elements)
        materials_data = search_materials_with_percentages(all_text)
        materials = materials_data["materials"]
        sustainability_score = materials_data["sustainability_score"]
        print("Extracted text:", all_text[:1000])
        print("Does 'cotton 11%' exist in text?:", "cotton 11%" in all_text)
        

    
    # Extract color from description or title
    color = extract_color_by_keywords(description)
    if color == "Not found":
        color = extract_color_by_keywords(title)
    
    # Fallback: Try extracting from URL if not found
    url_info = extract_info_from_url(url)
    if color == "Not found" and url_info.get("color") != "Not found":
        color = url_info["color"]
    if materials == "Not found" and url_info.get("material") != "Not found":
        materials = url_info["material"]

    category_search_text = " ".join([
        title if title != "Not found" else "",
        description if description != "Not found" else "",
        url
    ])
    
    # Detect category and subcategory
    category, subcategory = detect_clothing_category(category_search_text)
    
    # Compile product info
    product_info = {
        "name": name,
        "description": description,
        "image": image,
        "colour": color,
        "materials": materials,
        "sustainability_score": sustainability_score,
        "category": category,
        "subcategory": subcategory
    }
    print (materials)
    driver.quit()
    return product_info


def get_brand_from_url(source_url):
    """Extract brand from source_url using regex"""
    
    # Extract domain name from URL
    parsed_url = urlparse(source_url)
    domain = parsed_url.netloc.lower()  # Get the domain part, e.g., 'nike.com'

    # Regex to capture the word before '.com', '.co', '.org', etc.
    match = re.search(r'([a-zA-Z0-9-]+)(?=\.(com|co|org|net|io|store|shop|fr|uk))', domain)
    
    if match:
        return match.group(1).capitalize()  # Extracted brand name
    return ""


def add_to_wishlist(request, product_info, source_url):
    """Save extracted product to wishlist"""
    
    # List of known second-hand seller  keywords
    second_hand_sellers = [
        "ebay", "poshmark", "depop", "thredup", "vinted", "grailed", 
        "mercari", "vestiaire", "carousell", "tradesy", "facebook", 
    ]
    
    # Extract the domain from the source_url
    parsed_url = urlparse(source_url)
    domain = parsed_url.netloc.lower()
    
    brand = get_brand_from_url(source_url)
    
    # Check if any of the second-hand seller names/keywords exist in the domain
    second_hand = any(seller in domain for seller in second_hand_sellers)
    
    # Retrieve user profile and their size preferences
    user = request.user
    profile = UserProfile.objects.get(user=user)
    preferred_size = profile.preferred_size if profile else None
    preferred_footwear_size = profile.preferred_footwear_size if profile else None
    print(preferred_size)
    print(preferred_footwear_size)
    # Get category from product info
    category = product_info.get("category", "").upper()
    
    # Determine which size to use based on category
    if category == 'FOOTWEAR' and profile and profile.preferred_footwear_size:
        size = profile.preferred_footwear_size
    elif profile and profile.preferred_size:
        size = profile.preferred_size
    else:
        size = ""  # Default empty if no preferences exist
     
    # Clean category and subcategory values
    subcategory = product_info.get("subcategory", "").upper()
    category = category if category != "NOT FOUND" else ""
    subcategory = subcategory if subcategory != "NOT FOUND" else ""

    # Create wishlist item
    wishlist_item = Wishlist.objects.create(
        user=request.user,
        item_name=product_info["name"],
        source=source_url,
        material=product_info.get("materials", ""),  # Using get with default
        sustainable_score=product_info.get("sustainability_score", 0),
        description=product_info.get("description", ""),
        second_hand=second_hand,
        category=category,
        subcategory=subcategory,
        size=size,
        colour = product_info.get("colour", ""), 
        brand = brand
    )
 
    
    # Download and save image if available
    if product_info.get("image") and product_info["image"].upper() != "NOT FOUND":
        try:
            response = requests.get(product_info["image"])
            if response.status_code == 200:
                img_name = f"wishlist_{wishlist_item.id}.jpg"
                img_path = os.path.join(settings.MEDIA_ROOT, 'wishlist_items', img_name)
                
                # Create directory if it doesn't exist
                os.makedirs(os.path.dirname(img_path), exist_ok=True)
                
                with open(img_path, 'wb') as f:
                    f.write(response.content)
                
                wishlist_item.image = os.path.join('wishlist_items', img_name)
                wishlist_item.save()
        except Exception as e:
            print(f"Error saving wishlist image: {e}")
    
    return HttpResponseRedirect(reverse("webapp:view_wishlist"))




def view_wishlist(request):
   
    wishlist_items = Wishlist.objects.filter(user=request.user).order_by('-id')
    return render(request, "webapp/view_wishlist.html", {
        "wishlist_items": wishlist_items
    })

SUBCATEGORY_CHOICES = {
        'TOP': [
            ('SHIRT', 'Shirt'),
            ('T-SHIRT', 'T-Shirt'),
            ('BLOUSE', 'Blouse'),
            ('POLO', 'Polo Shirt'),
            ('TURTLE', 'Turtle Neck'),
            ('TANK_TOP', 'Tank Top'),
            ('CROP_TOP', 'Crop Top'),
            ('DRESS', 'Dress'),
            ('LONG_SLEEVE', 'Long Sleeved'),
            ('TUBE_TOP', 'Tube Top'),
           ],

        'BOTTOM': [
            ('JEANS', 'Jeans'),
            ('SHORTS', 'Shorts'),
            ('DRESS_PANTS', 'Dress Pants'),
            ('SKIRT', 'Skirt'),
            ('LEGGINGS', 'Leggings'),
            ('JOGGERS', 'Joggers'),
            ('PENCIL_SKIRT', 'Pencil Skirt'),  
            ('CHINOS', 'Chinos'),
        ],

        'FOOTWEAR': [
            ('SNEAKERS', 'Sneakers'),
            ('BOOTS', 'Boots'),
            ('SANDALS', 'Sandals'),
            ('LOAFERS', 'Loafers'),
            ('HEELS', 'Heels'),
            ('DRESS_SHOES', 'Dress Shoes'),

        ],
        'OUTERWEAR': [
            ('JACKET', 'Jacket'),
            ('COAT', 'Coat'),
            ('WINDBREAKER', 'Windbreaker'),
            ('LIGHT_JACKET', 'Light Jacket'),
            ('FLANNEL', 'Flannel Shirt'),
            ('SWEATER', 'Sweater'),
            ('SWEATSHIRT', 'Sweatshirt'),
            ('HOODIE', 'Hoodie'),
            ('CARDIGAN', 'Cardigan'),
            ('WAIST_COAT', 'Waist Coat'),
            ('BLAZER', 'Blazer'),
        ],
        'ACCESSORY': [
            ('HAT', 'Hat'),
            ('SCARF', 'Scarf'),
            ('BELT', 'Belt'),
            ('GLOVES', 'Gloves'),
            ('WATCH', 'Watch'),
            ('SUNGLASSES', 'Sunglasses'),
            ('TIE', 'Tie'),
        ],
    }

def detect_clothing_category(text):
    """
    Detect clothing category and subcategory from text.
    Returns tuple of (category, subcategory) where both can be None if not detected.
    """
    # Flatten all subcategories for searching
    ALL_SUBCATEGORIES = []
    for category, subcats in SUBCATEGORY_CHOICES.items():
        ALL_SUBCATEGORIES.extend([(sc[0], sc[1], category) for sc in subcats])
    
    #search text
    search_text = text.lower() # sets it to lower case
    search_text = re.sub(r'[^\w\s-]', '', search_text)  # regex Removes punctuations

    
    # Search for subcategory terms
    found_matches = [] #stores the matches that are found
    for sc_code, sc_name, category in ALL_SUBCATEGORIES:
        # Create different search patterns for different possible ormats
        patterns = [
            r'\b' + re.escape(sc_name.lower()) + r'\b',  # "t-shirt"
            r'\b' + re.escape(sc_code.lower().replace('_', '-')) + r'\b',  # "t-shirt"
            r'\b' + re.escape(sc_code.lower().replace('_', ' ')) + r'\b'   # "t shirt"
        ]
        
        if any(re.search(pattern, search_text) for pattern in patterns):
            found_matches.append((sc_code, sc_name, category, len(sc_name)))
    
    # If we found matches, return the most specific one (longest match)
    if found_matches:
        # Sort by match length (longest first) then alphabetically
        found_matches.sort(key=lambda x: (-x[3], x[1])) # lamda expression sorts by length of the match and then alphabetically
        return (found_matches[0][2], found_matches[0][0])  # (category, subcategory_code)
    
    # Fallback to category-only detection if no subcategory found
    CATEGORY_KEYWORDS = {
        'TOP': ['top', 'shirt', 'blouse', 'tee', 't-shirt'],
        'BOTTOM': ['pant', 'jean', 'short', 'skirt', 'legging', 'trouser'],
        'FOOTWEAR': ['shoe', 'boot', 'sandal', 'sneaker', 'footwear', 'loafer'],
        'OUTERWEAR': ['jacket', 'coat', 'hoodie', 'parka', 'outerwear', 'windbreaker', 'sweater', 'jumper', "sweatshirt"],
        'ACCESSORY': ['hat', 'scarf', 'belt', 'glove', 'accessory', 'sunglass', 'tie']
    }
    
    for category, keywords in CATEGORY_KEYWORDS.items():
        if any(keyword in search_text for keyword in keywords):
            return (category, None)  # Only category detected
    
    return (None, None)  # No matches found

def add_to_wardrobe(request, item_id): 
    # Get the wishlist item for the logged-in user
    wishlist_item = get_object_or_404(Wishlist, id=item_id, user=request.user)

    # Calculate carbon data based on the item’s material and second-hand status
    carbon_used, carbon_savings = calculate_carbon_impact(wishlist_item.material or "", wishlist_item.second_hand)

    # Create a new ClothingItem from the Wishlist item
    clothing_item = ClothingItem.objects.create(
        user=request.user,
        name=wishlist_item.item_name,
        description=wishlist_item.description,
        image=wishlist_item.image,
        second_hand=wishlist_item.second_hand,
        category=wishlist_item.category,
        subcategory=wishlist_item.subcategory,
        material=wishlist_item.material,
        colour=wishlist_item.colour,
        size=wishlist_item.size,
        brand=wishlist_item.brand,
        material_sustainability_score=wishlist_item.sustainable_score,
        carbon_used=carbon_used,
        carbon_savings=carbon_savings,
        sustainable_material=wishlist_item.sustainable_score <= 40,
    )

    # Update user goals
    goals = Goal.objects.filter(user=request.user, status='ONGOING')
    is_second_hand = wishlist_item.second_hand  
    is_sustainable = wishlist_item.sustainable_score <= 40  

    for goal in goals:
        if goal.goal_type == 'second_hand' and is_second_hand:
            goal.progress = (goal.progress or 0) + 1

        if goal.goal_type == 'sustainable_choices' and is_sustainable:
            goal.progress = (goal.progress or 0) + 1

        if goal.improvement_target is not None and (goal.progress or 0) >= goal.improvement_target:
            complete_goal(goal)

        goal.save()

    # Delete the wishlist item only once, after all goal updates
    wishlist_item.delete()

    return redirect('webapp:viewitem')



def remove_from_wishlist(request, item_id):
    item = get_object_or_404(Wishlist, id=item_id, user=request.user)
    item.delete()
    return redirect('webapp:wishlist')
 