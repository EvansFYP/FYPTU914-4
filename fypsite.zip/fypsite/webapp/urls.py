from django.urls import path

from . import views

app_name = "webapp"
urlpatterns = [
path("signup/", views.signup, name ="signup"),
path("signin/", views.signin, name = "signin"),
path("home/", views.homeview, name="home"),
path("additem/", views.additem, name ="additem"),
path("viewitem/", views.viewitem, name ="viewitem"),
path('itemdetail/<int:item_id>/', views.itemdetail, name='itemdetail'),
path('goals', views.goals, name='goals'),

]