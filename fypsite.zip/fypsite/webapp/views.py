from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.views import generic
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.utils.dateparse import parse_datetime
from django.contrib import admin

from .models import User
from .models import ClothingItem
CATEGORY_CHOICES = [
    ('TOP', 'Top'),
    ('BOTTOM', 'Bottom'),
    ('FOOTWEAR', 'Footwear'),
    ('OUTERWEAR', 'Outerwear'),
    ('ACCESSORY', 'Accessory'),
]

MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),


    ]


def signup(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signup.html", context)
    else:
        user = User.objects.create_user(
            username=request.POST["Username"],
            password=request.POST["Password"]
        )
        
        return HttpResponseRedirect(reverse("webapp:signin"))

def signin(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signin.html", context)
    else:
        user = authenticate(
            request,
            username=request.POST["Username"],
            password=request.POST["Password"]
        )

        if user is not None:
            login(request, user)
            print("logged in", user)
            return HttpResponseRedirect(reverse("webapp:home"))

def homeview(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/home.html", context) 
    
def additem(request):
    if request.method == "GET":
        context = {'categories': CATEGORY_CHOICES, 'material' : MATERIAL_CHOICES }
        return render(request, "webapp/additem.html", context)
    else:
        
        item_name = request.POST["name"]
        is_second_hand = request.POST["second_hand"] == "yes" 
        category = request.POST["category"] 
        material = request.POST["material"]
        colour = request.POST["colour"]
        size = request.POST["size"]
        purchase_date = request.POST["purchase_date"]
        if purchase_date == "":
            purchase_date = None 
        price = request.POST["price"]
        brand = request.POST["brand"]
        description = request.POST["description"]
        image = request.FILES.get("image", None)

        sustainable_material = False
        if material in ['COTTON', 'LINEN', 'BAMBOO', 'R-POLYESTER', 'LYOCELL', 'MODAL']:
            sustainable_material = True
        
        clothing_item = ClothingItem.objects.create(
            name=item_name,
            second_hand=is_second_hand,
            category =category,
            material = material,
            colour = colour,
            size = size,
            purchase_date = purchase_date,
            price = price,
            brand = brand,
            sustainable_material=sustainable_material,
            description = description,
            image=image,
            user=request.user

        )

        
        return HttpResponseRedirect(reverse("webapp:home"))

def viewitem(request):
    items = ClothingItem.objects.filter(user=request.user)  
    context ={'items': items }
    return render(request, 'webapp/viewitem.html',context)


def itemdetail(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    context = {
        'item': item,
    }
    
    
    return render(request, 'webapp/itemdetail.html', context)

def goals(request):
     if request.method == "GET":
        context = {}
        return render(request, "webapp/goals.html", context)

