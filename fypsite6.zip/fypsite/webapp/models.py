from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin


class ClothingItem(models.Model):
    CATEGORY_CHOICES = [
        ('TOP', 'Top'),
        ('BOTTOM', 'Bottom'),
        ('FOOTWEAR', 'Footwear'),
        ('OUTERWEAR', 'Outerwear'),
        ('ACCESSORY', 'Accessory'),
    ]



    SUBCATEGORY_CHOICES = {
        'TOP': [
            ('SHIRT', 'Shirt'),
            ('T-SHIRT', 'T-Shirt'),
            ('BLOUSE', 'Blouse'),
            ('SWEATER', 'Sweater'),
            ('HOODIE', 'Hoodie'),
            ('POLO', 'Polo Shirt'),
        ],
        'BOTTOM': [
            ('JEANS', 'Jeans'),
            ('SHORTS', 'Shorts'),
            ('PANTS', 'Pants'),
            ('SKIRT', 'Skirt'),
        ],
        'FOOTWEAR': [
            ('SNEAKERS', 'Sneakers'),
            ('BOOTS', 'Boots'),
            ('SANDALS', 'Sandals'),
            ('SHOES', 'Shoes'),
        ],
        'OUTERWEAR': [
            ('JACKET', 'Jacket'),
            ('COAT', 'Coat'),
            ('WINDBREAKER', 'Windbreaker'),
        ],
        'ACCESSORY': [
            ('HAT', 'Hat'),
            ('SCARF', 'Scarf'),
            ('BELT', 'Belt'),
            ('GLOVES', 'Gloves'),
        ],
    }



    MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('R-WOOL', 'Recycled Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),
        ('OTHER', 'Other'),


    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='clothing_items')
    name = models.CharField(max_length=100)
    second_hand = models.BooleanField(default=False)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    subcategory = models.CharField(max_length=50, blank=True, null=True)
    material = models.CharField(max_length=20, choices=MATERIAL_CHOICES, blank=True, null=True)
    colour = models.CharField(max_length=30, blank=True, null=True)
    size = models.CharField(max_length=10, blank=True, null=True)
    purchase_date = models.DateField(blank = True, null = True)
    date_added = models.DateField(default=timezone.now)
    last_worn_date = models.DateField(blank=True, null=True)
    worn_count = models.PositiveIntegerField(default=0)
    price = models.DecimalField(max_digits=6, decimal_places=2, blank=True, null=True, default=None)
    brand = models.CharField(max_length=100, blank=True, null=True)
    sustainable_material = models.BooleanField(default=False, blank =True, null = True)
    description = models.TextField(blank=True, null=True)
    image = models.ImageField(upload_to='clothing_items/', blank=True, null=True)
    wash_count = models.PositiveIntegerField(default = 0)
    material_sustainability_score = models.PositiveIntegerField(default=0)
    carbon_savings = models.PositiveIntegerField(default=0)
    
    
    #percentage going from 0-100 which is then measured on a scale of 0-4 
    MATERIAL_SUSTAINABILITY_SCORES = {
        'COTTON': 25,
        'WOOL': 30,
        'R-WOOL': 60,
        'SYNTHETIC': 15,
        'LEATHER': 20,
        'LINEN': 35,
        'POLYESTER': 15,
        'R-POLYESTER': 50,
        'LYOCELL': 60,
        'MODAL': 50,
        'NYLON': 20,
        'DENIM': 30,
        'SPANDEX': 15,
        'BAMBOO': 40,
        'ACRYLIC': 15,
        'OTHER': 20,
    }



    def wear(self): 
        self.worn_count += 1
        self.last_worn_date = timezone.now()
        self.save()
    
    def wash(self):
        self.wash_count += 1
        self.save()

    def get_subcategories(category):
     subcategories = ClothingItem.SUBCATEGORY_CHOICES.get(category, [])
     return subcategories


class Outfit(models.Model):
    name = models.CharField(max_length=100)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='outfit')
    clothing_items = models.ManyToManyField(ClothingItem, related_name="outfits")
    created_date = models.DateTimeField(auto_now_add=True)

    

    def __str__(self):
        return self.name
    

class Outfit_Schedule(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='outfit_schedule')
    outfit = models.ForeignKey(Outfit, on_delete=models.CASCADE, related_name='outfit_schedule')
    weather_condition = models.CharField(max_length=100)
    outfit_date = models.DateField(blank=True, null=True)

    OCCASION_CHOICES = [
        ('CASUAL', 'Casual'),
        ('FORMAL', 'Formal'),
        ('PARTY', 'Party'),
        ('WORK', 'Work'),
        ('HOLIDAY', 'Holiday'),
    ]
    
    occasion = models.CharField(max_length=20, choices=OCCASION_CHOICES, blank=True, null=True)

class Sustainability_Metrics(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sustainability_metrics')
    clothing_item = models.ForeignKey(ClothingItem, on_delete=models.CASCADE, related_name='sustainability_metrics')
    carbon_savings = models.PositiveIntegerField(default=0)
    item_usage_percentage = models.PositiveIntegerField(default=0)
    second_hand_percentage = models.PositiveIntegerField(default=0)
    susatainable_score = models.PositiveIntegerField(default=0)
    reportDate = models.DateField

class Goal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='goal')
    description = models.CharField(max_length=100)
    start_date = models.DateField(default=timezone.now)  
    end_date = models.DateField()  
    
    GOAL_CHOICES = [
        ('sustainable_scores', 'Improve Sustainability Score'),
        ('second_hand', 'Buy Second-Hand Items'),
        ('clothing_recycling', 'Recycle or Donate Clothing'),
        ('sustainable_choices', 'Acquire Sustainable Items'),
    ]
    
    goal_type = models.CharField(max_length=50, choices=GOAL_CHOICES, default='sustainable_score')
    
    STATUS_CHOICES = [
        ('ONGOING', 'Ongoing'),
        ('COMPLETE', 'Complete'),
        ('FAILED', 'Failed'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ONGOING')
    improvement_target = models.PositiveIntegerField(null=True, blank=True)


class Points(models.Model):
     user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='points')
     points_total = models.PositiveIntegerField(default=0) 
     points_earned = models.PositiveIntegerField(default=0)  
     date_earned = models.DateField(auto_now_add=True)        
     points_reason = models.CharField(max_length=255)

     def earn_points(self, amount, reason):
        
        self.points_earned += amount
        self.points_total += amount
        self.points_reason = reason
        self.save() 

class Wishlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='wishlist')
    item_name = models.CharField(max_length=100)  
    source = models.URLField(blank=True, null=True)  
    material = models.CharField(max_length=50, blank=True, null=True)  
    price = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    susatainable_rating = models.PositiveIntegerField(default=0)


class UploadedImage(models.Model):
    image = models.ImageField(upload_to='uploads/')  
    label = models.CharField(max_length=100, blank=True)  

    def __str__(self):
        return f"{self.image.name} - {self.label}"









    



 