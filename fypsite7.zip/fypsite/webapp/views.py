from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect
from django.urls import reverse
from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.utils.dateparse import parse_datetime
from django.contrib import admin
from colorthief import ColorThief
import requests
from django.http import JsonResponse
import requests
from datetime import date, timedelta, datetime 
from django.utils import timezone
import webcolors
import matplotlib
import numpy as np
from sklearn.neighbors import NearestNeighbors
from skimage.color import rgb2lab
import os
import kagglehub
from .models import ClothingItem
from .models import Outfit, Outfit_Schedule
from .models import Sustainability_Metrics
from .models import Goal
from .models import Point
from django.utils.timezone import now







os.environ['KAGGLE_USERNAME'] = 'evanweldon'
os.environ['KAGGLE_KEY'] = 'd1385dc18ea673a0a35bdf000f61e175'









CATEGORY_CHOICES = [
    ('TOP', 'Top'),
    ('BOTTOM', 'Bottom'),
    ('FOOTWEAR', 'Footwear'),
    ('OUTERWEAR', 'Outerwear'),
    ('ACCESSORY', 'Accessory'),
]

MATERIAL_CHOICES = [
        ('COTTON', 'Cotton'),
        ('WOOL', 'Wool'),
        ('R-WOOL', 'Recycled Wool'),
        ('SYNTHETIC', 'Synthetic'),
        ('LEATHER', 'Leather'),
        ('LINEN', 'Linen'),
        ('POLYESTER', 'Polyester'),
        ('R-POLYESTER', 'Recycled Polyester'),
        ('LYOCELL', 'Lyocell/Organic Cotton'),
        ('MODAL', 'Modal'),
        ('NYLON', 'Nylon'),
        ('DENIM', 'Denim'),
        ('SPANDEX', 'Spandex'),
        ('BAMBOO', 'Bamboo'),
        ('ACRYLIC', 'Acrylic'),
        ('OTHER', 'Other'),

    ]


def signup(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signup.html", context)
    else:
        user = User.objects.create_user(
            username=request.POST["Username"],
            password=request.POST["Password"]
        )
        
        return HttpResponseRedirect(reverse("webapp:signin"))

def signin(request):
    if request.method == "GET":
        context = {}
        return render(request, "webapp/signin.html", context)
    else:
        user = authenticate(
            request,
            username=request.POST["Username"],
            password=request.POST["Password"]
        )

        if user is not None:
            login(request, user)
            print("logged in", user)
            return HttpResponseRedirect(reverse("webapp:home"))
        


def get_lat_lon():
    
    url = "http://ip-api.com/json/"
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        if data["status"] == "success":
            latitude = round(data["lat"], 6)  
            longitude = round(data["lon"], 6)
            return latitude, longitude
        else:
            print("Error retrieving city-based location data.")
            return None, None, None
    except requests.RequestException as e:
        print(f"Error retrieving geolocation data: {e}")
        return None, None, None


lat, lon = get_lat_lon()
print(f"Latitude: {lat}, Longitude: {lon}")



def fetch_weather_forecast(latitude, longitude):
  
    api_key = "GBWM6TUL5HEYSSSTUSAEFPVH6" #my api key for Visual Crossing
    weather_url = (
        f"https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast"
        f"?key={api_key}&unitGroup=metric&contentType=json&aggregateHours=24&locations={latitude},{longitude}"
    )
    weather_response = requests.get(weather_url)#get request to api 
    weather_data = weather_response.json() #convert to json format 

    # Extract the forecast for the next 7 days
    location_key = f"{latitude},{longitude}"
    forecast_data = weather_data['locations'][location_key]['values'][:7]

    # Convert timestamps to datetime objects
    for day in forecast_data:
        timestamp = day['datetime']
        day['datetime'] = datetime.fromtimestamp(timestamp / 1000)  #changes timestamps to seconds
        print(f"Your Latitude: {latitude}, Your Longitude: {longitude}")

    return forecast_data





def homeview(request):
    if request.method == "GET":
        latitude, longitude = get_lat_lon() #retrieve latitude and longitude 
        
        
        forecast_data = fetch_weather_forecast(latitude, longitude) #pass it to the weather function and retrieve forecast data

        user = request.user 

       
        scheduled_outfits = schedule_outfits_for_forecast(user, forecast_data) # pass the data and user to the outfit scheduler 


        #pass both as context to the home page
        context = {
            'outfits_for_week': scheduled_outfits,
            'forecast': forecast_data,
        }
        return render(request, 'webapp/home.html', context)

    return render(request, 'webapp/home.html', {'error': 'Invalid request method.'})




def get_colour_name(rgb_triplet):
    #list of common human color names and their hex values
    myColors = {
        "red"     : "#ff0000",
        "orange"  : "#ffa500",
        "yellow"  : "#ffff00",
        "green"   : "#008000",
        "blue"    : "#0000ff",
        "magenta" : "#ff00ff",
        "purple"  : "#800080",
        "coral"   : "#ff7f50",
        "maroon"  : "#800000",
        "navy"    : "#000080",
        "cyan"    : "#00ffff",
        "gold"    : "#ffd700",
        "lime"    : "#00ff00",
        "jade"    : "#00a36c",
        "olive"   : "#808000",
        "gray"    : "#808080",
        "cream"   : "#fffdd0",
        "white"   : "#ffffff",
        "black"   : "#000000",
        "teal"    : "#008080",
        "sky blue": "#87CEEB",
        "brown"   : "#a52a2a"
    }
    
    # Find the closest color match based the passed RGB values
    min_colours = {}
    for name, hex_val in myColors.items():
        r_c, g_c, b_c = webcolors.hex_to_rgb(hex_val)
        rd = (r_c - rgb_triplet[0]) ** 2
        gd = (g_c - rgb_triplet[1]) ** 2
        bd = (b_c - rgb_triplet[2]) ** 2
        min_colours[(rd + gd + bd)] = name
    
    return min_colours[min(min_colours.keys())]

    
 
    
def additem(request):
    if request.method == "GET":
        context = {'categories': CATEGORY_CHOICES, 'material': MATERIAL_CHOICES}
        return render(request, "webapp/additem.html", context)
    else:
        item_name = request.POST["name"]
        second_hand = request.POST["second_hand"]
        if second_hand == "true":
            is_second_hand = True
            carbon_savings = 3  
        else:
            is_second_hand = False
            carbon_savings = 0 

        category = request.POST["category"]
        material = request.POST["material"]
        size = request.POST["size"]
        purchase_date = request.POST["purchase_date"]
        if purchase_date == "":
            purchase_date = None
        brand = request.POST["brand"]
        description = request.POST["description"]
        image = request.FILES.get("image", None)

        colour = None
        if image:
            color_thief = ColorThief(image)
            dominant_rgb = color_thief.get_color(quality=10)
            colour = get_colour_name(dominant_rgb)

        ##scoring based on textileexchange index//rework?
        MATERIAL_SUSTAINABILITY_SCORES = {
    'Cotton': 25,
    'Wool': 30,
    'Recycled Wool': 60,
    'Synthetic': 15,
    'Leather': 20,
    'Linen': 35,
    'Polyester': 15,
    'Recycled Polyester': 50,
    'Lyocell/Organic Cotton': 60,
    'Modal': 50,
    'Nylon': 20,
    'Denim': 30,
    'Spandex': 15,
    'Bamboo': 40,
    'Acrylic': 15,
    'Other': 20,
}
        
        
        material_sustainability_score = MATERIAL_SUSTAINABILITY_SCORES.get(material, 0)
        sustainable_material = material_sustainability_score >= 40 

        
        clothing_item = ClothingItem.objects.create(
            name=item_name,
            second_hand=is_second_hand,
            category=category,
            material=material,
            colour=colour,
            size=size,
            purchase_date=purchase_date,
            brand=brand,
            sustainable_material=sustainable_material,
            material_sustainability_score=material_sustainability_score,
            carbon_savings=carbon_savings, 
            description=description,
            image=image,
            user=request.user
        )

        goals = Goal.objects.filter(user=request.user, status='ONGOING')

        for goal in goals:
            if goal.goal_type == 'second_hand' and is_second_hand:
                goal.progress += 1
            elif goal.goal_type == 'sustainable_choices' and sustainable_material:
                goal.progress += 1

           
            if goal.progress >= goal.improvement_target:
                complete_goal(goal)

            goal.save() 

       
        return HttpResponseRedirect(reverse("webapp:edititem", kwargs={"item_id": clothing_item.id}))
        

    


def viewitem(request):
    items = ClothingItem.objects.filter(user=request.user)  
    context ={'items': items }
    return render(request, 'webapp/viewitem.html',context)


def itemdetail(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    context = {
        'item': item,
    }
    
    
    return render(request, 'webapp/itemdetail.html', context)

def goals(request):
     if request.method == "GET":
        context = {}

        points = Point.objects.filter(user=request.user).first()
     if points:
                points_total = points.points_total
     else:
                points_total = 0 

     context['points_total'] = points_total

     return render(request, "webapp/goals.html", context)


def deleteitem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    if request.method == 'GET':
        item.delete()
        return redirect('webapp:viewitem')
    

def edititem(request, item_id):
    item = get_object_or_404(ClothingItem, id=item_id, user=request.user)
    
    categories = ClothingItem.CATEGORY_CHOICES  
    materials = ClothingItem.MATERIAL_CHOICES  

    if request.method == "POST":
       
        item.name = request.POST["name"]
        item.second_hand = request.POST["second_hand"] == "true"
        item.category = request.POST["category"]
        item.material = request.POST["material"]
        item.colour = request.POST["colour"]
        item.size = request.POST["size"]
        item.purchase_date = request.POST["purchase_date"] if request.POST["purchase_date"] else None
        item.brand = request.POST["brand"]
        item.description = request.POST["description"]
        item.image = request.FILES.get("image", item.image)  

       
        sustainable_material = item.material in ['COTTON', 'LINEN', 'BAMBOO', 'R-POLYESTER', 'LYOCELL', 'MODAL']
        item.sustainable_material = sustainable_material
        
        
        item.save()

      
        return redirect('webapp:viewitem')

    context = {
        'item': item,
        'categories': categories,
        'materials': materials
    }
    return render(request, "webapp/edititem.html", context)




def select_outfit_based_on_weather(temp, conditions, user, occasion=None):
    # Define the categories based on temperature and conditions
    if temp > 20:
        outfit_categories = ['TOP', 'BOTTOM', 'FOOTWEAR']
    elif 10 <= temp <= 20:
        outfit_categories = ['TOP', 'BOTTOM', 'FOOTWEAR', 'OUTERWEAR']
    else:
        outfit_categories = ['TOP', 'BOTTOM', 'FOOTWEAR', 'OUTERWEAR', 'ACCESSORY']

    if 'Rain' in conditions:
        outfit_categories.append('OUTERWEAR')

    outfit_items = []  # List to store selected clothing items
    categories_with_items = set()  # Set to track categories with at least one item

    # Select clothing items based on category and worn count
    for category in outfit_categories:
        items = user.clothing_items.filter(category=category).order_by('worn_count', 'last_worn_date')
        if items.exists():
            selected_item = items.first()
            outfit_items.append(selected_item)
            categories_with_items.add(category)  # Add category to the set

    # Check if there are at least 5 different categories with items
    if len(categories_with_items) >= 5:
        # Create outfit
        if outfit_items:
            outfit = Outfit.objects.create(name=f"Outfit for {user.username}", user=user)
            outfit.clothing_items.set(outfit_items)
            outfit.save()

            if occasion:
                Outfit_Schedule.objects.create(
                    user=user,
                    outfit=outfit,
                    weather_condition=f"{temp}°C, {conditions}",
                    occasion=occasion
                )

            return outfit
    else:
        print(f"User {user.username} does not enough clothing items to create an outfit.")
        return None




def schedule_outfits_for_forecast(user, forecast_data):
    outfits_for_week = [] 

    # Check if the user has clothing items
    if not user.clothing_items.exists():
        print(f"No clothing items for user {user.username}.")
        return {'error': 'No clothing items available for this user.'}

    # Loop through forecast data
    for i, day_forecast in enumerate(forecast_data):
        temp = day_forecast['temp']
        conditions = day_forecast['conditions']
        outfit_date = date.today() + timedelta(days=i)

        print(f"Processing forecast for date: {outfit_date}, Temp: {temp}, Conditions: {conditions}")

        # Check if an outfit is already scheduled for this date
        outfit_schedule = Outfit_Schedule.objects.filter(user=user, outfit_date=outfit_date).first()

        if outfit_schedule:
            print(f"Outfit already scheduled for {outfit_date}.")
            outfits_for_week.append(outfit_schedule.outfit) 

            # If the date has reached, increment the worn count only once per day
            if outfit_schedule.outfit_date == date.today():
                for item in outfit_schedule.outfit.clothing_items.all():
                    if item.last_worn_update != date.today():
                        item.worn_count += 1  # Increment worn_count
                        item.last_worn_update = date.today()  # Update the last worn date
                        item.save()
                        
        else:
            print(f"No outfit scheduled for {outfit_date}. Generating new outfit.")
            outfit = select_outfit_based_on_weather(temp, conditions, user)
            if outfit:
                Outfit_Schedule.objects.create(
                    user=user,
                    outfit=outfit,
                    weather_condition=f"{temp}°C, {conditions}",
                    outfit_date=outfit_date
                )
                print(f"Outfit scheduled for {outfit_date}.")
                outfits_for_week.append(outfit)

    return outfits_for_week





def outfit_detail(request, outfit_date):
    user = request.user
    outfit_schedule = get_object_or_404(Outfit_Schedule, user=user, outfit_date=outfit_date)
    outfit = outfit_schedule.outfit
    return render(request, 'webapp/outfit_detail.html', {'outfit': outfit, 'outfit_schedule': outfit_schedule, 'date' : outfit_date})




def calculate_reusability_score(worn_count, time_in_wardrobe):
    # Calculate the score as a ratio of worn_count to time_in_wardrobe
    if time_in_wardrobe > 0:
        score = (worn_count / time_in_wardrobe) * 100
        # Ensure the score doesn't exceed 100
        return min(score, 100)
    return 0


def calculate_sustainability_metrics(request):
    if request.user.is_authenticated:
        user = request.user

        # Fetch all clothing item
        clothing_items = ClothingItem.objects.filter(user=user)

        if not clothing_items.exists():
            return render(request, 'webapp/error_page.html', {'error': 'No clothing items found for the user.'})

        
        total_material_score = 0
        total_carbon_savings = 0
        second_hand_items = 0
        total_items = clothing_items.count()
        total_reusability_score = 0

        # Loop through clothing items
        for item in clothing_items:
            total_material_score += item.material_sustainability_score
            total_carbon_savings += item.carbon_savings

            if item.second_hand:
                second_hand_items += 1

            # Calculate time in wardrobe
            time_in_wardrobe = (date.today() - item.date_added).days if item.date_added else 0

            # Calculate the reusability score
            total_reusability_score += calculate_reusability_score(item.worn_count, time_in_wardrobe)

        # Calculate percentages and averages
        second_hand_percentage = (second_hand_items / total_items) * 100 if total_items > 0 else 0
        avg_material_score = total_material_score / total_items if total_items > 0 else 0
        avg_reusability_score = total_reusability_score / total_items if total_items > 0 else 0

        # Final sustainable score 
        sustainable_score = int(
            avg_material_score * 0.3 + avg_reusability_score * 0.4 + second_hand_percentage * 0.3
        )  

       
        today = now().date()

        # Check if a Sustainability_Metrics object already exists for today
        metrics, created = Sustainability_Metrics.objects.update_or_create(
            user=user,
            reportDate=today,
            defaults={
                'carbon_savings': total_carbon_savings,
                'item_usage_percentage': avg_reusability_score,  
                'second_hand_percentage': second_hand_percentage,
                'susatainable_score': sustainable_score,
            }
        )

        # Pass as context  to the report.html
        context = {
            'carbon_savings': metrics.carbon_savings,
            'item_usage_percentage': metrics.item_usage_percentage,
            'second_hand_percentage': metrics.second_hand_percentage,
            'sustainable_score': metrics.susatainable_score,
            'report_date': metrics.reportDate,
            'status': 'created' if created else 'updated',
        }

        return render(request, 'webapp/sustainability_report.html', context)

    return render(request, 'webapp/error_page.html', {'error': 'User not authenticated.'})




def create_goal(request):
    user = request.user
    if request.method == 'POST':
        

        end_date = request.POST.get('end_date')
        goal_type = request.POST.get('goal_type')
        improvement_target = request.POST.get('improvement_target', None)
        second_hand_target = request.POST.get('second_hand_target', None)
        clothing_recycling_target = request.POST.get('clothing_recycling_target', None)
        sustainable_choices_target = request.POST.get('sustainable_choices_target', None)


        target = None

        initial_score = 0 
        if goal_type == 'sustainable_scores':
            target = improvement_target
            sustainability_score = Sustainability_Metrics.objects.filter(user=user).first()
            initial_score = sustainability_score.susatainable_score if sustainability_score else 0

        elif goal_type == 'second_hand':
            target = second_hand_target
        elif goal_type == 'clothing_recycling':
            target = clothing_recycling_target
        elif goal_type == 'sustainable_choices':
            target = sustainable_choices_target
        
        
        
        start_date = timezone.now().date()

        goal_descriptions = {
            'carbon_reduction': "This goal focuses on reducing your carbon footprint by making environmentally conscious choices.",
            'second_hand': "This goal encourages acquiring second-hand items to reduce waste and support sustainable consumption.",
            'clothing_recycling': "This goal promotes recycling or donating clothing items to extend their lifecycle and reduce landfill waste.",
            'sustainable_choices': "This goal aims to acquire sustainable items that align with eco-friendly practices."
        }

       
        description = goal_descriptions.get(goal_type, "No description available for this goal type.")
      
        goal = Goal.objects.create(
            user=request.user,
            description=description,
            start_date=start_date,
            end_date=end_date,
            goal_type=goal_type,
            improvement_target=target,
            initial_score=initial_score,
            
        )

        
        return redirect('webapp:goals_list')  

    else:
     
    
        return render(request, 'webapp/goals.html')
    
def goals_list(request):
  
    goals = Goal.objects.filter(user=request.user)

    now = timezone.now().date()
   
    for goal in goals:##loop through goals and check if any goals have expired if they have set status to failed
        
        if goal.end_date < now and goal.status != 'COMPLETE':
            goal.status = 'FAILED'
            goal.save()
    
    return render(request, 'webapp/goals_list.html', {'goals': goals})

def cancel_goal(request, goal_id):
    
    goal = get_object_or_404(Goal, id=goal_id)

    
    if request.method == 'POST':
        status = request.POST.get('status')

        if status == 'CANCELLED':
            
            goal.delete()
            return redirect('webapp:goals_list')  
        
     
        goal.status = status
        goal.save()

        return redirect('webapp:goals_list')



def check_goal_completion(user):
    today = now().date()
    goals = Goal.objects.filter(user=user, status='ONGOING')


    sustainability = Sustainability_Metrics.objects.filter(user=user).first()

    if not sustainability:
        return  

    for goal in goals:
        if goal.goal_type == 'sustainable_scores':
          
            initial_score = goal.initial_score  

         
            current_score = sustainability.susatainable_score  

            target_score = initial_score * (1 + (goal.improvement_target / 100))

        
            if current_score >= target_score:
                complete_goal(goal)

        elif goal.goal_type == 'clothing_recycling':
            if goal.progress >= goal.improvement_target:
                complete_goal(goal)

        goal.save()

def complete_goal(goal):
    goal.status = 'COMPLETE'
    goal.save()

    last_point = Point.objects.filter(user=goal.user).order_by('-date_earned').first()
    previous_total = last_point.points_total if last_point else 0  

    Point.objects.create(
        user=goal.user,
        points_earned=5,  
        points_total=previous_total + 5, 
        points_reason=f"Completed goal"
    )

  




       



    



    