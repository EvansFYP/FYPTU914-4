from django.contrib import admin

from .models import ClothingItem
from .models import Outfit
from .models import Outfit_Schedule
from .models import Goal
from .models import Sustainability_Metrics
from .models import Point
from .models import Wishlist


admin.site.register(ClothingItem)
admin.site.register(Outfit)
admin.site.register(Outfit_Schedule)
admin.site.register(Goal)
admin.site.register(Sustainability_Metrics)
admin.site.register(Point)
admin.site.register(Wishlist)